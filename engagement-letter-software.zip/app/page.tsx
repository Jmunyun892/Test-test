"use client"

import { useState, useEffect } from "react"
import { AppContent } from "@/components/app-content"
import { Spinner } from "@/components/ui/spinner"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Spinner className="h-8 w-8" />
          <p className="text-muted-foreground">Loading EngageLetter...</p>
        </div>
      </div>
    )
  }

  return <AppContent />
}
