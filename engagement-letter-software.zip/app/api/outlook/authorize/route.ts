import { NextRequest, NextResponse } from "next/server"
import { OUTLOOK_OAUTH, getOutlookAuthorizeUrl } from "@/lib/outlook-graph"

export async function GET(request: NextRequest) {
  try {
    if (!OUTLOOK_OAUTH.clientId?.trim() || !OUTLOOK_OAUTH.clientSecret?.trim()) {
      return NextResponse.redirect(
        new URL(
          `/?outlook_error=${encodeURIComponent("Outlook OAuth is not configured (set NEXT_PUBLIC_MICROSOFT_CLIENT_ID and MICROSOFT_CLIENT_SECRET)")}`,
          request.url
        )
      )
    }

    const state = crypto.randomUUID()
    const authUrl = getOutlookAuthorizeUrl(state)
    const response = NextResponse.redirect(authUrl)
    response.cookies.set("outlook_oauth_state", state, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 600,
      path: "/",
    })
    return response
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: "Outlook authorize failed" }, { status: 500 })
  }
}
