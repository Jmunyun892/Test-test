import { NextRequest, NextResponse } from "next/server"
import {
  GraphApiError,
  graphListCalendarView,
  refreshOutlookToken,
} from "@/lib/outlook-graph"
import { graphEventToMeeting } from "@/lib/outlook-meetings"
import type { Meeting } from "@/lib/types"

type Serialized = Omit<Meeting, "date" | "createdAt" | "updatedAt"> & {
  date: string
  createdAt: string
  updatedAt: string
}

function serialize(m: Meeting): Serialized {
  return {
    ...m,
    date: m.date.toISOString(),
    createdAt: m.createdAt.toISOString(),
    updatedAt: m.updatedAt.toISOString(),
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}))
    let accessToken: string | null =
      request.headers.get("x-outlook-token") || body.accessToken || null
    const refreshToken: string | null =
      request.headers.get("x-outlook-refresh-token") || body.refreshToken || null

    const daysBack = Math.min(90, Math.max(0, Number(body.daysBack) || 14))
    const daysAhead = Math.min(180, Math.max(1, Number(body.daysAhead) || 60))

    if (!accessToken) {
      return NextResponse.json({ error: "No access token" }, { status: 401 })
    }

    const end = new Date()
    end.setUTCDate(end.getUTCDate() + daysAhead)
    const start = new Date()
    start.setUTCDate(start.getUTCDate() - daysBack)

    const fetchEvents = async (token: string) => {
      const raw = await graphListCalendarView(token, start, end)
      const meetings: Meeting[] = []
      for (const evt of raw) {
        const m = graphEventToMeeting(evt)
        if (m) meetings.push(m)
      }
      return meetings
    }

    let newTokens:
      | { accessToken: string; refreshToken: string; expiresAt: number }
      | undefined

    let meetings: Meeting[]
    try {
      meetings = await fetchEvents(accessToken)
    } catch (err) {
      const is401 = err instanceof GraphApiError && err.status === 401
      if (is401 && refreshToken) {
        const t = await refreshOutlookToken(refreshToken)
        accessToken = t.access_token
        newTokens = {
          accessToken: t.access_token,
          refreshToken: t.refresh_token || refreshToken,
          expiresAt: Date.now() + t.expires_in * 1000,
        }
        meetings = await fetchEvents(accessToken)
      } else {
        throw err
      }
    }

    const payload: {
      meetings: Serialized[]
      newTokens?: typeof newTokens
    } = { meetings: meetings.map(serialize) }
    if (newTokens) payload.newTokens = newTokens

    return NextResponse.json(payload)
  } catch (e) {
    console.error(e)
    if (e instanceof GraphApiError && e.status === 401) {
      return NextResponse.json(
        { error: "Outlook session expired", needsReauth: true },
        { status: 401 }
      )
    }
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Calendar sync failed" },
      { status: 500 }
    )
  }
}
