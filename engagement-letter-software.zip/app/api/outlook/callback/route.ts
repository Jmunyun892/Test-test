import { NextRequest, NextResponse } from "next/server"
import {
  exchangeOutlookCode,
  graphGetMe,
} from "@/lib/outlook-graph"

export async function GET(request: NextRequest) {
  try {
    const params = request.nextUrl.searchParams
    const code = params.get("code")
    const state = params.get("state")
    const error = params.get("error")
    const errDesc = params.get("error_description")

    if (error) {
      return NextResponse.redirect(
        new URL(
          `/?outlook_error=${encodeURIComponent(errDesc || error)}`,
          request.url
        )
      )
    }

    if (!code) {
      return NextResponse.redirect(
        new URL("/?outlook_error=no_code", request.url)
      )
    }

    const stored = request.cookies.get("outlook_oauth_state")?.value
    if (state && stored && state !== stored) {
      return NextResponse.redirect(
        new URL("/?outlook_error=state_mismatch", request.url)
      )
    }

    const tokens = await exchangeOutlookCode(code)
    const me = await graphGetMe(tokens.access_token)

    const connectionData = {
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token ?? "",
      expiresAt: Date.now() + tokens.expires_in * 1000,
      userId: me.id,
      email: me.mail || me.userPrincipalName || "",
      displayName: me.displayName || "",
    }

    const encoded = Buffer.from(JSON.stringify(connectionData)).toString("base64")
    const response = NextResponse.redirect(
      new URL(`/?outlook_connected=true&data=${encoded}`, request.url)
    )
    response.cookies.delete("outlook_oauth_state")
    return response
  } catch (e) {
    console.error(e)
    return NextResponse.redirect(
      new URL(
        `/?outlook_error=${encodeURIComponent(
          e instanceof Error ? e.message : "unknown"
        )}`,
        request.url
      )
    )
  }
}
