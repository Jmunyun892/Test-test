import { NextRequest, NextResponse } from "next/server"
import { exchangeCodeForTokens, getZoomUser } from "@/lib/zoom"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const code = searchParams.get("code")
    const state = searchParams.get("state")
    const error = searchParams.get("error")

    // Check for errors from Zoom
    if (error) {
      console.error("Zoom OAuth error:", error)
      return NextResponse.redirect(
        new URL(`/?zoom_error=${encodeURIComponent(error)}`, request.url)
      )
    }

    // Verify code exists
    if (!code) {
      return NextResponse.redirect(
        new URL("/?zoom_error=no_code", request.url)
      )
    }

    // Verify state matches (CSRF protection)
    const storedState = request.cookies.get("zoom_oauth_state")?.value
    if (state && storedState && state !== storedState) {
      console.error("State mismatch:", { state, storedState })
      return NextResponse.redirect(
        new URL("/?zoom_error=state_mismatch", request.url)
      )
    }

    // Exchange code for tokens
    const tokens = await exchangeCodeForTokens(code)
    
    // Get user info
    const user = await getZoomUser(tokens.access_token)
    
    // Create the connection data to pass to frontend
    const connectionData = {
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiresAt: Date.now() + tokens.expires_in * 1000,
      userId: user.id,
      email: user.email,
      displayName: user.display_name || `${user.first_name} ${user.last_name}`,
      accountId: user.account_id,
    }

    // Encode connection data for URL (will be stored client-side)
    const encodedData = Buffer.from(JSON.stringify(connectionData)).toString("base64")

    // Redirect to app with connection data
    const response = NextResponse.redirect(
      new URL(`/?zoom_connected=true&data=${encodedData}`, request.url)
    )

    // Clear the state cookie
    response.cookies.delete("zoom_oauth_state")

    return response
  } catch (error) {
    console.error("Zoom callback error:", error)
    return NextResponse.redirect(
      new URL(
        `/?zoom_error=${encodeURIComponent(
          error instanceof Error ? error.message : "Unknown error"
        )}`,
        request.url
      )
    )
  }
}
