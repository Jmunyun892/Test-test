import { NextRequest, NextResponse } from "next/server"
import { ZOOM_CONFIG } from "@/lib/zoom"

export async function POST(request: NextRequest) {
  try {
    const { accessToken } = await request.json()

    if (accessToken) {
      // Revoke the token with Zoom
      const credentials = Buffer.from(
        `${ZOOM_CONFIG.clientId}:${ZOOM_CONFIG.clientSecret}`
      ).toString("base64")

      await fetch("https://zoom.us/oauth/revoke", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Basic ${credentials}`,
        },
        body: new URLSearchParams({
          token: accessToken,
        }),
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Disconnect error:", error)
    // Return success anyway - user can still disconnect locally
    return NextResponse.json({ success: true })
  }
}
