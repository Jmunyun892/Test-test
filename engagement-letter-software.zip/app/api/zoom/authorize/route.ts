import { NextRequest, NextResponse } from "next/server"
import { ZOOM_CONFIG, getZoomAuthUrl } from "@/lib/zoom"

export async function GET(request: NextRequest) {
  try {
    if (!ZOOM_CONFIG.clientId?.trim() || !ZOOM_CONFIG.clientSecret?.trim()) {
      return NextResponse.redirect(
        new URL(
          `/?zoom_error=${encodeURIComponent("Zoom OAuth is not configured (missing client id or secret)")}`,
          request.url
        )
      )
    }

    // Generate a state parameter to prevent CSRF
    const state = crypto.randomUUID()
    
    // Get the Zoom authorization URL
    const authUrl = getZoomAuthUrl(state)
    
    // Create response with redirect
    const response = NextResponse.redirect(authUrl)
    
    // Store state in a cookie for verification in callback
    response.cookies.set("zoom_oauth_state", state, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 10, // 10 minutes
      path: "/",
    })
    
    return response
  } catch (error) {
    console.error("Zoom auth error:", error)
    return NextResponse.json(
      { error: "Failed to initiate Zoom authorization" },
      { status: 500 }
    )
  }
}
