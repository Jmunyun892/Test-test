import { NextRequest, NextResponse } from "next/server"
import {
  ZoomApiError,
  getZoomRecordings,
  refreshAccessToken,
} from "@/lib/zoom"

export async function GET(request: NextRequest) {
  try {
    let accessToken = request.headers.get("x-zoom-token")
    const refreshToken = request.headers.get("x-zoom-refresh-token")

    if (!accessToken) {
      return NextResponse.json(
        { error: "No access token provided" },
        { status: 401 }
      )
    }

    const to = new Date().toISOString().split("T")[0]
    const from = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0]

    const fetchPage = async (token: string) =>
      getZoomRecordings(token, from, to)

    try {
      const recordings = await fetchPage(accessToken)
      return NextResponse.json(recordings)
    } catch (error) {
      const needsRefresh =
        error instanceof ZoomApiError
          ? error.status === 401
          : false

      if (refreshToken && needsRefresh) {
        try {
          const newTokens = await refreshAccessToken(refreshToken)
          accessToken = newTokens.access_token
          const recordings = await fetchPage(accessToken)

          return NextResponse.json({
            ...recordings,
            newTokens: {
              accessToken: newTokens.access_token,
              refreshToken: newTokens.refresh_token,
              expiresAt: Date.now() + newTokens.expires_in * 1000,
            },
          })
        } catch {
          return NextResponse.json(
            { error: "Token refresh failed", needsReauth: true },
            { status: 401 }
          )
        }
      }

      throw error
    }
  } catch (error) {
    console.error("Recordings API error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch recordings" },
      { status: 500 }
    )
  }
}
