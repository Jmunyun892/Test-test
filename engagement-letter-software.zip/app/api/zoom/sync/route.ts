import { NextRequest, NextResponse } from "next/server"
import {
  ZoomApiError,
  downloadZoomCloudFile,
  fetchAllZoomRecordings,
  refreshAccessToken,
  type ZoomRecordingMeeting,
} from "@/lib/zoom"
import {
  meetingFromZoomRecording,
  parseWebVTT,
} from "@/lib/zoom-transcript"
import type { Meeting } from "@/lib/types"

type SerializedMeeting = Omit<Meeting, "date" | "createdAt" | "updatedAt"> & {
  date: string
  createdAt: string
  updatedAt: string
}

function serializeMeeting(m: Meeting): SerializedMeeting {
  return {
    ...m,
    date: m.date.toISOString(),
    createdAt: m.createdAt.toISOString(),
    updatedAt: m.updatedAt.toISOString(),
  }
}

async function buildMeetingsFromRecordings(
  accessToken: string,
  recordings: ZoomRecordingMeeting[]
): Promise<Meeting[]> {
  const results: Meeting[] = []

  for (const rec of recordings) {
    const files = rec.recording_files ?? []
    const transcriptFile = files.find((f) => {
      if (f.file_type !== "TRANSCRIPT" || !f.download_url) return false
      const st = (f.status || "completed").toLowerCase()
      return st === "completed"
    })

    let transcript: { timestamp: string; speaker: string; text: string }[] = []

    if (transcriptFile?.download_url) {
      try {
        const raw = await downloadZoomCloudFile(
          accessToken,
          transcriptFile.download_url
        )
        transcript = parseWebVTT(raw)
      } catch {
        transcript = []
      }
    }

    results.push(
      meetingFromZoomRecording({
        recording: rec,
        transcript,
      })
    )
  }

  return results
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}))
    let accessToken: string | null =
      request.headers.get("x-zoom-token") || body.accessToken || null
    const refreshToken: string | null =
      request.headers.get("x-zoom-refresh-token") || body.refreshToken || null

    const days = Math.min(
      90,
      Math.max(1, Number(body.daysBack) || 60)
    )
    const to = new Date().toISOString().split("T")[0]!
    const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0]!

    if (!accessToken) {
      return NextResponse.json(
        { error: "No access token provided" },
        { status: 401 }
      )
    }

    const trySync = async (token: string) => {
      const recordings = await fetchAllZoomRecordings(token, from, to)
      const meetings = await buildMeetingsFromRecordings(token, recordings)
      return meetings
    }

    let newTokens:
      | { accessToken: string; refreshToken: string; expiresAt: number }
      | undefined

    let meetings: Meeting[]
    try {
      meetings = await trySync(accessToken)
    } catch (err) {
      const is401 =
        err instanceof ZoomApiError
          ? err.status === 401
          : false
      if (is401 && refreshToken) {
        const tokens = await refreshAccessToken(refreshToken)
        accessToken = tokens.access_token
        newTokens = {
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          expiresAt: Date.now() + tokens.expires_in * 1000,
        }
        meetings = await trySync(accessToken)
      } else {
        throw err
      }
    }

    const payload: {
      meetings: SerializedMeeting[]
      newTokens?: typeof newTokens
      range: { from: string; to: string }
    } = {
      meetings: meetings.map(serializeMeeting),
      range: { from, to },
    }
    if (newTokens) payload.newTokens = newTokens

    return NextResponse.json(payload)
  } catch (error) {
    console.error("Zoom sync error:", error)
    if (error instanceof ZoomApiError && error.status === 401) {
      return NextResponse.json(
        { error: "Zoom session expired", needsReauth: true },
        { status: 401 }
      )
    }
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Failed to sync Zoom recordings",
      },
      { status: 500 }
    )
  }
}
