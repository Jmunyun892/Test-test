import { NextRequest, NextResponse } from "next/server"
import { unsealStreamContext } from "@/lib/zoom-stream-crypto"
import { zoomRecordingPlaybackUrl } from "@/lib/zoom-playback"

const COOKIE = "zoom_rec_ctx"

export async function GET(request: NextRequest) {
  const qp = request.nextUrl.searchParams.get("ctx")
  const cookieVal = request.cookies.get(COOKIE)?.value
  const raw = qp || cookieVal
  if (!raw) {
    return NextResponse.json({ error: "Missing stream session" }, { status: 401 })
  }

  const ctx = unsealStreamContext(raw)
  if (!ctx) {
    return NextResponse.json({ error: "Invalid or expired session" }, { status: 401 })
  }

  const upstreamUrl = zoomRecordingPlaybackUrl(
    ctx.u,
    ctx.t ? ctx.t : undefined
  )
  if (!upstreamUrl) {
    return NextResponse.json({ error: "Bad URL" }, { status: 400 })
  }

  const range = request.headers.get("range")
  const upstream = await fetch(upstreamUrl, {
    headers: range ? { Range: range } : {},
    redirect: "follow",
  })

  const headers = new Headers()
  const pass = [
    "content-type",
    "content-length",
    "content-range",
    "accept-ranges",
    "cache-control",
  ] as const
  for (const h of pass) {
    const v = upstream.headers.get(h)
    if (v) headers.set(h, v)
  }

  return new NextResponse(upstream.body, {
    status: upstream.status,
    headers,
  })
}
