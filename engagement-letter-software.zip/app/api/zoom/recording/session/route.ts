import { NextRequest, NextResponse } from "next/server"
import { sealStreamContext } from "@/lib/zoom-stream-crypto"

const COOKIE = "zoom_rec_ctx"
const STREAM_PATH = "/api/zoom/recording/stream"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}))
    const recordingUrl = typeof body.recordingUrl === "string" ? body.recordingUrl : ""
    if (!recordingUrl.trim()) {
      return NextResponse.json({ error: "recordingUrl required" }, { status: 400 })
    }

    let url: URL
    try {
      url = new URL(recordingUrl)
    } catch {
      return NextResponse.json({ error: "Invalid recording URL" }, { status: 400 })
    }

    if (!/^https?:$/i.test(url.protocol)) {
      return NextResponse.json({ error: "URL must be http(s)" }, { status: 400 })
    }

    const zoomToken =
      request.headers.get("x-zoom-token")?.trim() ||
      (typeof body.accessToken === "string" ? body.accessToken.trim() : "")

    const sealed = sealStreamContext(recordingUrl, zoomToken, 7200)

    if (sealed.length > 3800) {
      const streamUrl = `${STREAM_PATH}?ctx=${encodeURIComponent(sealed)}`
      return NextResponse.json({ ok: true, streamUrl })
    }

    const res = NextResponse.json({ ok: true, streamPath: STREAM_PATH })
    res.cookies.set(COOKIE, sealed, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: STREAM_PATH,
      maxAge: 7200,
    })
    return res
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: "Session error" }, { status: 500 })
  }
}
