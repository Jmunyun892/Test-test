"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import {
  LayoutDashboard,
  FileText,
  PenLine,
  Settings,
  HelpCircle,
  ChevronRight,
  TrendingUp,
  Target,
  Video,
} from "lucide-react"
import { useEngagementStore } from "@/lib/engagement-store"
import { cn } from "@/lib/utils"

const navigation = [
  { name: "Dashboard", icon: LayoutDashboard, view: "dashboard" as const },
  { name: "Letters", icon: FileText, view: "letters" as const },
  { name: "Sales", icon: TrendingUp, view: "sales" as const },
  { name: "Sales KPIs", icon: Target, view: "weekly-kpi" as const },
  { name: "Notetaker", icon: Video, view: "notetaker" as const },
]

const secondaryNavigation = [
  { name: "Settings", icon: Settings },
  { name: "Help", icon: HelpCircle },
]

export function AppSidebar() {
  const [mounted, setMounted] = useState(false)
  const { view, setView, setSelectedLetter } = useEngagementStore()

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleNavigation = (targetView: "dashboard" | "letters" | "editor" | "sales" | "weekly-kpi" | "notetaker") => {
    if (targetView === "editor") {
      setSelectedLetter(null)
    }
    setView(targetView)
  }

  return (
    <aside className="flex h-screen w-64 flex-col border-r border-border bg-sidebar">
      <div className="flex h-20 items-center border-b border-border px-4">
        <Image
          src="/images/ghl-logo.svg"
          alt="GHL Logo"
          width={220}
          height={60}
          className="h-14 w-auto"
          priority
        />
      </div>

      <nav className="flex-1 space-y-1 px-3 py-4">
        <p className="mb-2 px-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Main
        </p>
        {navigation.map((item) => {
          const isActive = mounted && view === item.view
          return (
            <button
              key={item.name}
              onClick={() => handleNavigation(item.view)}
              className={cn(
                "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.name}
              {isActive && (
                <ChevronRight className="ml-auto h-4 w-4" />
              )}
            </button>
          )
        })}

        <div className="my-4 border-t border-border" />

        <p className="mb-2 px-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Support
        </p>
        {secondaryNavigation.map((item) => (
          <button
            key={item.name}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
          >
            <item.icon className="h-4 w-4" />
            {item.name}
          </button>
        ))}
      </nav>

      <div className="border-t border-border p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-sm font-medium text-secondary-foreground">
            JD
          </div>
          <div className="flex-1 truncate">
            <p className="text-sm font-medium text-sidebar-foreground">
              John Doe
            </p>
            <p className="text-xs text-muted-foreground">john@company.com</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
