"use client"

import { useState, useEffect, useMemo } from "react"
import {
  ArrowLeft,
  Bold,
  Italic,
  Underline,
  List,
  ListOrdered,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Heading1,
  Heading2,
  Save,
  Send,
  Eye,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useEngagementStore } from "@/lib/engagement-store"
import { cn } from "@/lib/utils"

const serviceTypes = [
  "Audit",
  "Tax",
  "Bookkeeping",
  "Advisory",
  "Review",
  "Payroll",
  "Consulting",
  "Other",
]

const editorButtons = [
  { icon: Bold, command: "bold", label: "Bold" },
  { icon: Italic, command: "italic", label: "Italic" },
  { icon: Underline, command: "underline", label: "Underline" },
  { type: "separator" },
  { icon: Heading1, command: "formatBlock", value: "h2", label: "Heading 1" },
  { icon: Heading2, command: "formatBlock", value: "h3", label: "Heading 2" },
  { type: "separator" },
  { icon: List, command: "insertUnorderedList", label: "Bullet List" },
  { icon: ListOrdered, command: "insertOrderedList", label: "Numbered List" },
  { type: "separator" },
  { icon: AlignLeft, command: "justifyLeft", label: "Align Left" },
  { icon: AlignCenter, command: "justifyCenter", label: "Align Center" },
  { icon: AlignRight, command: "justifyRight", label: "Align Right" },
]

const defaultContent = `<h2>Engagement Letter</h2>
<p>Dear [Client Name],</p>
<p>We are pleased to confirm our understanding of the services we are to provide.</p>
<h3>Scope of Services</h3>
<p>Enter the scope of services here...</p>
<h3>Fees</h3>
<p>Our fees for this engagement will be...</p>
<h3>Terms and Conditions</h3>
<p>Payment is due within 30 days of invoice date.</p>
<p>Sincerely,</p>
<p>[Your Name]<br/>[Your Title]</p>`

export function LetterEditor() {
  const {
    letters,
    selectedLetterId,
    setView,
    setSelectedLetter,
    addLetter,
    updateLetter,
  } = useEngagementStore()

  const existingLetter = useMemo(
    () => letters.find((l) => l.id === selectedLetterId),
    [letters, selectedLetterId]
  )

  const [mounted, setMounted] = useState(false)
  const [title, setTitle] = useState("")
  const [clientName, setClientName] = useState("")
  const [clientEmail, setClientEmail] = useState("")
  const [serviceType, setServiceType] = useState("")
  const [value, setValue] = useState("")
  const [content, setContent] = useState(defaultContent)
  const [isPreview, setIsPreview] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (existingLetter) {
      setTitle(existingLetter.title)
      setClientName(existingLetter.clientName)
      setClientEmail(existingLetter.clientEmail)
      setServiceType(existingLetter.serviceType)
      setValue(existingLetter.value.toString())
      setContent(existingLetter.content)
    } else {
      setTitle("")
      setClientName("")
      setClientEmail("")
      setServiceType("")
      setValue("")
      setContent(defaultContent)
    }
  }, [existingLetter])

  const handleCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value)
  }

  const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
    setContent(e.currentTarget.innerHTML)
  }

  const handleSave = (sendAfterSave = false) => {
    const letterData = {
      title: title || "Untitled Letter",
      clientName,
      clientEmail,
      serviceType: serviceType || "Other",
      content,
      value: parseFloat(value) || 0,
      status: sendAfterSave ? ("sent" as const) : ("draft" as const),
      sentAt: sendAfterSave ? new Date() : undefined,
    }

    if (existingLetter) {
      updateLetter(existingLetter.id, letterData)
    } else {
      addLetter(letterData)
    }

    setView("letters")
  }

  const handleBack = () => {
    setSelectedLetter(null)
    setView("letters")
  }

  if (!mounted) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-muted-foreground">Loading editor...</div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-semibold text-foreground">
            {existingLetter ? "Edit Letter" : "New Engagement Letter"}
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={() => setIsPreview(!isPreview)}
            className="gap-2"
          >
            <Eye className="h-4 w-4" />
            {isPreview ? "Edit" : "Preview"}
          </Button>
          <Button variant="outline" onClick={() => handleSave(false)} className="gap-2">
            <Save className="h-4 w-4" />
            Save Draft
          </Button>
          <Button onClick={() => handleSave(true)} className="gap-2">
            <Send className="h-4 w-4" />
            Save & Send
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Letter Details */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base">Letter Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter letter title"
                className="bg-secondary border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="clientName">Client Name</Label>
              <Input
                id="clientName"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Enter client name"
                className="bg-secondary border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="clientEmail">Client Email</Label>
              <Input
                id="clientEmail"
                type="email"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                placeholder="client@example.com"
                className="bg-secondary border-border"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="serviceType">Service Type</Label>
              <Select value={serviceType} onValueChange={setServiceType}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Select service type" />
                </SelectTrigger>
                <SelectContent>
                  {serviceTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="value">Engagement Value ($)</Label>
              <Input
                id="value"
                type="number"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="0"
                className="bg-secondary border-border"
              />
            </div>
          </CardContent>
        </Card>

        {/* Editor */}
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Letter Content</CardTitle>
          </CardHeader>
          <CardContent>
            {!isPreview && (
              <div className="mb-4 flex flex-wrap items-center gap-1 rounded-lg border border-border bg-secondary p-2">
                {editorButtons.map((button, index) =>
                  button.type === "separator" ? (
                    <div
                      key={index}
                      className="mx-1 h-6 w-px bg-border"
                    />
                  ) : (
                    <button
                      key={index}
                      onClick={() =>
                        handleCommand(button.command!, button.value)
                      }
                      className="rounded p-2 text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
                      title={button.label}
                    >
                      {button.icon && <button.icon className="h-4 w-4" />}
                    </button>
                  )
                )}
              </div>
            )}

            <div
              className={cn(
                "min-h-[500px] rounded-lg border border-border p-6",
                isPreview
                  ? "bg-background"
                  : "bg-secondary focus:outline-none focus:ring-2 focus:ring-ring"
              )}
              contentEditable={!isPreview}
              dangerouslySetInnerHTML={{ __html: content }}
              onInput={handleContentChange}
              suppressContentEditableWarning
              style={{
                lineHeight: 1.6,
              }}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
