"use client"

import { useMemo, useState, useEffect } from "react"
import {
  ArrowLeft,
  Edit2,
  Send,
  Download,
  Trash2,
  CheckCircle2,
  Clock,
  FileText,
  User,
  Mail,
  Calendar,
  DollarSign,
  Briefcase,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useEngagementStore } from "@/lib/engagement-store"
import type { LetterStatus } from "@/lib/types"
import { cn } from "@/lib/utils"

const statusConfig: Record<
  string,
  { label: string; color: string; icon: typeof CheckCircle2 }
> = {
  draft: { label: "Draft", color: "bg-amber-400/20 text-amber-400", icon: FileText },
  sent: { label: "Sent", color: "bg-blue-400/20 text-blue-400", icon: Send },
  viewed: { label: "Viewed", color: "bg-purple-400/20 text-purple-400", icon: FileText },
  won: { label: "Won", color: "bg-emerald-400/20 text-emerald-400", icon: CheckCircle2 },
  signed: { label: "Won", color: "bg-emerald-400/20 text-emerald-400", icon: CheckCircle2 }, // Legacy
  expired: { label: "Expired", color: "bg-chart-4/20 text-chart-4", icon: Clock },
  rejected: { label: "Rejected", color: "bg-destructive/20 text-destructive", icon: Trash2 },
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

function formatDate(date: Date | undefined): string {
  if (!date) return "-"
  return new Date(date).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  })
}

export function LetterDetail() {
  const [mounted, setMounted] = useState(false)
  const {
    letters,
    selectedLetterId,
    setView,
    setSelectedLetter,
    updateLetter,
    deleteLetter,
  } = useEngagementStore()

  useEffect(() => {
    setMounted(true)
  }, [])

  const letter = useMemo(
    () => letters.find((l) => l.id === selectedLetterId),
    [letters, selectedLetterId]
  )

  if (!mounted) {
    return (
      <div className="flex flex-1 items-center justify-center p-6">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  if (!letter) {
    return (
      <div className="flex flex-1 items-center justify-center p-6">
        <p className="text-muted-foreground">Letter not found</p>
      </div>
    )
  }

  const statusInfo = statusConfig[letter.status]
  const StatusIcon = statusInfo.icon

  const handleBack = () => {
    setSelectedLetter(null)
    setView("letters")
  }

  const handleEdit = () => {
    setView("editor")
  }

  const handleSend = () => {
    updateLetter(letter.id, {
      status: "sent",
      sentAt: new Date(),
    })
  }

  const handleDelete = () => {
    deleteLetter(letter.id)
    setSelectedLetter(null)
    setView("letters")
  }

  const handleMarkViewed = () => {
    updateLetter(letter.id, {
      status: "viewed",
    })
  }

  const handleMarkWon = () => {
    updateLetter(letter.id, {
      status: "won",
      signedAt: new Date(),
    })
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="mb-6 flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <div className="flex-1">
          <h1 className="text-2xl font-semibold text-foreground">
            {letter.title}
          </h1>
          <p className="text-sm text-muted-foreground">
            Created {formatDate(letter.createdAt)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {letter.status === "draft" && (
            <Button variant="outline" onClick={handleSend} className="gap-2">
              <Send className="h-4 w-4" />
              Send
            </Button>
          )}
          {letter.status === "sent" && (
            <Button
              variant="outline"
              onClick={handleMarkViewed}
              className="gap-2"
            >
              <FileText className="h-4 w-4" />
              Mark as Viewed
            </Button>
          )}
          {(letter.status === "sent" || letter.status === "viewed") && (
            <Button
              variant="outline"
              onClick={handleMarkWon}
              className="gap-2"
            >
              <CheckCircle2 className="h-4 w-4" />
              Mark as Won
            </Button>
          )}
          <Button variant="outline" onClick={handleEdit} className="gap-2">
            <Edit2 className="h-4 w-4" />
            Edit
          </Button>
          <Button
            variant="outline"
            onClick={handleDelete}
            className="gap-2 text-destructive hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Details Sidebar */}
        <div className="space-y-6">
          {/* Status */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <span
                className={cn(
                  "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium",
                  statusInfo.color
                )}
              >
                <StatusIcon className="h-4 w-4" />
                {statusInfo.label}
              </span>
            </CardContent>
          </Card>

          {/* Client Info */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Client Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-foreground">
                  {letter.clientName}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-foreground">
                  {letter.clientEmail}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Engagement Details */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Engagement Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <Briefcase className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-foreground">
                  {letter.serviceType}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">
                  {formatCurrency(letter.value)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Timeline */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Timeline
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Created</p>
                  <p className="text-sm text-foreground">
                    {formatDate(letter.createdAt)}
                  </p>
                </div>
              </div>
              {letter.sentAt && (
                <div className="flex items-center gap-3">
                  <Send className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Sent</p>
                    <p className="text-sm text-foreground">
                      {formatDate(letter.sentAt)}
                    </p>
                  </div>
                </div>
              )}
              {letter.signedAt && (
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  <div>
                    <p className="text-xs text-muted-foreground">Signed</p>
                    <p className="text-sm text-foreground">
                      {formatDate(letter.signedAt)}
                    </p>
                  </div>
                </div>
              )}
              {letter.expiresAt && (
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-chart-4" />
                  <div>
                    <p className="text-xs text-muted-foreground">Expires</p>
                    <p className="text-sm text-foreground">
                      {formatDate(letter.expiresAt)}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Letter Content */}
        <Card className="bg-card border-border lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base">Letter Content</CardTitle>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
          </CardHeader>
          <CardContent>
            <div
              className="min-h-[500px] rounded-lg border border-border bg-background p-6 prose prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: letter.content }}
              style={{ lineHeight: 1.6 }}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
