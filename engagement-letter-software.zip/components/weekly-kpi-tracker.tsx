"use client"

import { useState, useEffect, useMemo } from "react"
import {
  Phone,
  PhoneOff,
  DollarSign,
  Users,
  Calendar,
  PhoneIncoming,
  Target,
  Plus,
  Edit2,
  Trash2,
  Settings,
  TrendingUp,
  TrendingDown,
  ChevronLeft,
  ChevronRight,
  Check,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  RadialBarChart,
  RadialBar,
} from "recharts"
import { useEngagementStore } from "@/lib/engagement-store"
import type { WeeklyKPIEntry, WeeklyKPIGoals } from "@/lib/types"
import { cn } from "@/lib/utils"

// Helper function to get Monday of a week
function getMonday(d: Date): Date {
  const date = new Date(d)
  const day = date.getDay()
  const diff = date.getDate() - day + (day === 0 ? -6 : 1)
  date.setDate(diff)
  date.setHours(0, 0, 0, 0)
  return date
}

// Helper function to get Sunday of a week
function getSunday(d: Date): Date {
  const monday = getMonday(d)
  const sunday = new Date(monday)
  sunday.setDate(monday.getDate() + 6)
  return sunday
}

// Format date to ISO string (YYYY-MM-DD)
function formatDateISO(d: Date): string {
  return d.toISOString().split("T")[0]
}

// Format date for display
function formatDateDisplay(dateStr: string): string {
  const date = new Date(dateStr + "T00:00:00")
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
}

const kpiMetrics = [
  { key: "discoveryCalls", label: "Discovery Calls", icon: Phone, type: "count" },
  { key: "unqualifiedDeals", label: "Unqualified Deals", icon: PhoneOff, type: "count" },
  { key: "pricingCalls", label: "Pricing Calls", icon: PhoneIncoming, type: "count" },
  { key: "mrrProposed", label: "MRR Proposed", icon: DollarSign, type: "currency" },
  { key: "backworkProposed", label: "Backwork Proposed", icon: DollarSign, type: "currency" },
  { key: "backworkClosed", label: "Backwork Closed", icon: Check, type: "currency" },
  { key: "mrrClosed", label: "MRR Closed", icon: TrendingUp, type: "currency" },
  { key: "numberOfClients", label: "New Clients", icon: Users, type: "count" },
  { key: "networkingEvents", label: "Networking Events", icon: Calendar, type: "count" },
  { key: "clientCheckInCalls", label: "Client Check-ins", icon: Phone, type: "count" },
] as const

type MetricKey = (typeof kpiMetrics)[number]["key"]

interface FormData {
  discoveryCalls: number
  unqualifiedDeals: number
  pricingCalls: number
  mrrProposed: number
  backworkProposed: number
  backworkClosed: number
  mrrClosed: number
  numberOfClients: number
  networkingEvents: number
  clientCheckInCalls: number
  notes: string
}

const defaultFormData: FormData = {
  discoveryCalls: 0,
  unqualifiedDeals: 0,
  pricingCalls: 0,
  mrrProposed: 0,
  backworkProposed: 0,
  backworkClosed: 0,
  mrrClosed: 0,
  numberOfClients: 0,
  networkingEvents: 0,
  clientCheckInCalls: 0,
  notes: "",
}

export function WeeklyKPITracker() {
  const [mounted, setMounted] = useState(false)
  const {
    weeklyKPIs,
    weeklyGoals,
    addWeeklyKPI,
    updateWeeklyKPI,
    deleteWeeklyKPI,
    updateWeeklyGoals,
  } = useEngagementStore()

  const [selectedWeekStart, setSelectedWeekStart] = useState<string>("")
  const [isEntryDialogOpen, setIsEntryDialogOpen] = useState(false)
  const [isGoalsDialogOpen, setIsGoalsDialogOpen] = useState(false)
  const [editingEntry, setEditingEntry] = useState<WeeklyKPIEntry | null>(null)
  const [formData, setFormData] = useState<FormData>(defaultFormData)
  const [goalsFormData, setGoalsFormData] = useState<WeeklyKPIGoals>(weeklyGoals)
  const [activeTab, setActiveTab] = useState<"current" | "history" | "trends">("current")

  useEffect(() => {
    setMounted(true)
    const monday = getMonday(new Date())
    setSelectedWeekStart(formatDateISO(monday))
  }, [])

  // Get sorted KPIs after mounted
  const sortedKPIs = useMemo(() => {
    if (!mounted) return []
    return [...weeklyKPIs].sort(
      (a, b) => new Date(b.weekStartDate).getTime() - new Date(a.weekStartDate).getTime()
    )
  }, [mounted, weeklyKPIs])

  // Get current week's entry
  const currentWeekEntry = useMemo(() => {
    if (!mounted || !selectedWeekStart) return null
    return weeklyKPIs.find((entry) => entry.weekStartDate === selectedWeekStart) || null
  }, [mounted, weeklyKPIs, selectedWeekStart])

  // Calculate progress against goals
  const progressData = useMemo(() => {
    if (!mounted || !currentWeekEntry) return null
    return kpiMetrics.map((metric) => {
      const current = currentWeekEntry[metric.key as MetricKey] as number
      const goal = weeklyGoals[metric.key as MetricKey]
      const percentage = goal > 0 ? Math.min((current / goal) * 100, 100) : 0
      return {
        ...metric,
        current,
        goal,
        percentage: Math.round(percentage),
        isAboveGoal: current >= goal,
      }
    })
  }, [mounted, currentWeekEntry, weeklyGoals])

  // Calculate weekly trends
  const trendData = useMemo(() => {
    if (!mounted || sortedKPIs.length === 0) return []
    return sortedKPIs.slice(0, 8).reverse().map((entry) => ({
      week: formatDateDisplay(entry.weekStartDate),
      discoveryCalls: entry.discoveryCalls,
      pricingCalls: entry.pricingCalls,
      mrrClosed: entry.mrrClosed,
      backworkClosed: entry.backworkClosed,
      newClients: entry.numberOfClients,
    }))
  }, [mounted, sortedKPIs])

  const navigateWeek = (direction: "prev" | "next") => {
    const current = new Date(selectedWeekStart + "T00:00:00")
    const newDate = new Date(current)
    newDate.setDate(current.getDate() + (direction === "next" ? 7 : -7))
    setSelectedWeekStart(formatDateISO(newDate))
  }

  const handleOpenEntryDialog = (entry?: WeeklyKPIEntry) => {
    if (entry) {
      setEditingEntry(entry)
      setFormData({
        discoveryCalls: entry.discoveryCalls,
        unqualifiedDeals: entry.unqualifiedDeals,
        pricingCalls: entry.pricingCalls,
        mrrProposed: entry.mrrProposed,
        backworkProposed: entry.backworkProposed,
        backworkClosed: entry.backworkClosed,
        mrrClosed: entry.mrrClosed,
        numberOfClients: entry.numberOfClients,
        networkingEvents: entry.networkingEvents,
        clientCheckInCalls: entry.clientCheckInCalls,
        notes: entry.notes || "",
      })
    } else {
      setEditingEntry(null)
      setFormData(defaultFormData)
    }
    setIsEntryDialogOpen(true)
  }

  const handleSaveEntry = () => {
    const sunday = getSunday(new Date(selectedWeekStart + "T00:00:00"))
    
    if (editingEntry) {
      updateWeeklyKPI(editingEntry.id, {
        ...formData,
      })
    } else {
      addWeeklyKPI({
        weekStartDate: selectedWeekStart,
        weekEndDate: formatDateISO(sunday),
        ...formData,
      })
    }
    setIsEntryDialogOpen(false)
    setEditingEntry(null)
    setFormData(defaultFormData)
  }

  const handleDeleteEntry = (id: string) => {
    if (confirm("Are you sure you want to delete this week's data?")) {
      deleteWeeklyKPI(id)
    }
  }

  const handleSaveGoals = () => {
    updateWeeklyGoals(goalsFormData)
    setIsGoalsDialogOpen(false)
  }

  const formatValue = (value: number, type: string) => {
    if (type === "currency") {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(value)
    }
    return value.toString()
  }

  if (!mounted) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <div className="text-muted-foreground">Loading KPI tracker...</div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-3xl text-foreground">WEEKLY KPI TRACKER</h1>
            <p className="text-muted-foreground">Track and analyze your weekly sales activities</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setGoalsFormData(weeklyGoals)
                setIsGoalsDialogOpen(true)
              }}
            >
              <Settings className="mr-2 h-4 w-4" />
              Goals
            </Button>
            {!currentWeekEntry && (
              <Button onClick={() => handleOpenEntryDialog()}>
                <Plus className="mr-2 h-4 w-4" />
                Add Week Data
              </Button>
            )}
          </div>
        </div>

        {/* Week Selector */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <Button variant="ghost" size="icon" onClick={() => navigateWeek("prev")}>
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <div className="text-center">
                <p className="text-lg font-semibold text-foreground">
                  Week of {formatDateDisplay(selectedWeekStart)}
                </p>
                <p className="text-sm text-muted-foreground">
                  {formatDateDisplay(selectedWeekStart)} - {formatDateDisplay(formatDateISO(getSunday(new Date(selectedWeekStart + "T00:00:00"))))}
                </p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => navigateWeek("next")}>
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
          <TabsList className="bg-secondary">
            <TabsTrigger value="current">Current Week</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
          </TabsList>

          {/* Current Week Tab */}
          <TabsContent value="current" className="space-y-6">
            {currentWeekEntry ? (
              <>
                {/* KPI Cards Grid */}
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
                  {progressData?.map((metric) => (
                    <Card key={metric.key} className="bg-card border-border">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                            <metric.icon className="h-5 w-5 text-primary" />
                          </div>
                          <div
                            className={cn(
                              "flex items-center gap-1 text-xs font-medium",
                              metric.isAboveGoal ? "text-success" : "text-muted-foreground"
                            )}
                          >
                            {metric.isAboveGoal ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : (
                              <TrendingDown className="h-3 w-3" />
                            )}
                            {metric.percentage}%
                          </div>
                        </div>
                        <div className="mt-3">
                          <p className="text-2xl font-bold text-foreground">
                            {formatValue(metric.current, metric.type)}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {metric.label}
                          </p>
                        </div>
                        <div className="mt-2">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Goal: {formatValue(metric.goal, metric.type)}</span>
                          </div>
                          <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                            <div
                              className={cn(
                                "h-full rounded-full transition-all",
                                metric.isAboveGoal ? "bg-success" : "bg-primary"
                              )}
                              style={{ width: `${metric.percentage}%` }}
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Progress Overview */}
                <div className="grid gap-6 lg:grid-cols-2">
                  {/* Radial Progress Chart */}
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <CardTitle className="text-foreground">Goal Progress</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <RadialBarChart
                          cx="50%"
                          cy="50%"
                          innerRadius="20%"
                          outerRadius="90%"
                          data={progressData?.slice(0, 6).map((d, i) => ({
                            name: d.label,
                            value: d.percentage,
                            fill: `hsl(${260 + i * 20}, 60%, 50%)`,
                          }))}
                          startAngle={180}
                          endAngle={0}
                        >
                          <RadialBar
                            dataKey="value"
                            background={{ fill: "var(--secondary)" }}
                            cornerRadius={4}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "var(--card)",
                              border: "1px solid var(--border)",
                              borderRadius: "8px",
                            }}
                            formatter={(value: number, name: string) => [`${value}%`, name]}
                          />
                          <Legend
                            iconSize={10}
                            layout="horizontal"
                            verticalAlign="bottom"
                            wrapperStyle={{ fontSize: "12px", color: "var(--muted-foreground)" }}
                          />
                        </RadialBarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  {/* Revenue Summary */}
                  <Card className="bg-card border-border">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle className="text-foreground">Revenue Summary</CardTitle>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleOpenEntryDialog(currentWeekEntry)}>
                            <Edit2 className="mr-2 h-4 w-4" />
                            Edit Week
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => handleDeleteEntry(currentWeekEntry.id)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete Week
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="rounded-lg bg-secondary p-4">
                          <p className="text-sm text-muted-foreground">MRR Proposed</p>
                          <p className="text-2xl font-bold text-foreground">
                            {formatValue(currentWeekEntry.mrrProposed, "currency")}
                          </p>
                        </div>
                        <div className="rounded-lg bg-secondary p-4">
                          <p className="text-sm text-muted-foreground">MRR Closed</p>
                          <p className="text-2xl font-bold text-success">
                            {formatValue(currentWeekEntry.mrrClosed, "currency")}
                          </p>
                        </div>
                        <div className="rounded-lg bg-secondary p-4">
                          <p className="text-sm text-muted-foreground">Backwork Proposed</p>
                          <p className="text-2xl font-bold text-foreground">
                            {formatValue(currentWeekEntry.backworkProposed, "currency")}
                          </p>
                        </div>
                        <div className="rounded-lg bg-secondary p-4">
                          <p className="text-sm text-muted-foreground">Backwork Closed</p>
                          <p className="text-2xl font-bold text-success">
                            {formatValue(currentWeekEntry.backworkClosed, "currency")}
                          </p>
                        </div>
                      </div>
                      {currentWeekEntry.notes && (
                        <div className="rounded-lg border border-border bg-secondary/50 p-4">
                          <p className="text-sm font-medium text-foreground">Notes</p>
                          <p className="mt-1 text-sm text-muted-foreground">
                            {currentWeekEntry.notes}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </>
            ) : (
              <Card className="bg-card border-border">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Target className="h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-semibold text-foreground">No Data for This Week</h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Start tracking your KPIs by adding this week&apos;s data.
                  </p>
                  <Button className="mt-4" onClick={() => handleOpenEntryDialog()}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Week Data
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-4">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-foreground">Weekly History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="py-3 text-left font-medium text-muted-foreground">Week</th>
                        <th className="py-3 text-center font-medium text-muted-foreground">Discovery</th>
                        <th className="py-3 text-center font-medium text-muted-foreground">Pricing</th>
                        <th className="py-3 text-center font-medium text-muted-foreground">MRR Closed</th>
                        <th className="py-3 text-center font-medium text-muted-foreground">Backwork</th>
                        <th className="py-3 text-center font-medium text-muted-foreground">Clients</th>
                        <th className="py-3 text-center font-medium text-muted-foreground">Events</th>
                        <th className="py-3 text-right font-medium text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedKPIs.map((entry) => (
                        <tr key={entry.id} className="border-b border-border/50">
                          <td className="py-3 text-foreground">
                            {formatDateDisplay(entry.weekStartDate)} - {formatDateDisplay(entry.weekEndDate)}
                          </td>
                          <td className="py-3 text-center text-foreground">{entry.discoveryCalls}</td>
                          <td className="py-3 text-center text-foreground">{entry.pricingCalls}</td>
                          <td className="py-3 text-center text-success">
                            {formatValue(entry.mrrClosed, "currency")}
                          </td>
                          <td className="py-3 text-center text-success">
                            {formatValue(entry.backworkClosed, "currency")}
                          </td>
                          <td className="py-3 text-center text-foreground">{entry.numberOfClients}</td>
                          <td className="py-3 text-center text-foreground">{entry.networkingEvents}</td>
                          <td className="py-3 text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <Edit2 className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => {
                                    setSelectedWeekStart(entry.weekStartDate)
                                    handleOpenEntryDialog(entry)
                                  }}
                                >
                                  <Edit2 className="mr-2 h-4 w-4" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-destructive"
                                  onClick={() => handleDeleteEntry(entry.id)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {sortedKPIs.length === 0 && (
                    <div className="flex flex-col items-center justify-center py-8">
                      <p className="text-muted-foreground">No history yet. Start tracking your weeks!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trends Tab */}
          <TabsContent value="trends" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Calls Trend */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Call Activity Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="week" stroke="var(--muted-foreground)" fontSize={12} />
                      <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                          borderRadius: "8px",
                        }}
                      />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="discoveryCalls"
                        name="Discovery"
                        stroke="var(--chart-1)"
                        strokeWidth={2}
                        dot={{ fill: "var(--chart-1)" }}
                      />
                      <Line
                        type="monotone"
                        dataKey="pricingCalls"
                        name="Pricing"
                        stroke="var(--chart-2)"
                        strokeWidth={2}
                        dot={{ fill: "var(--chart-2)" }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Revenue Trend */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Revenue Closed Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="week" stroke="var(--muted-foreground)" fontSize={12} />
                      <YAxis
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                        tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                          borderRadius: "8px",
                        }}
                        formatter={(value: number) => [
                          new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                            minimumFractionDigits: 0,
                          }).format(value),
                        ]}
                      />
                      <Legend />
                      <Bar dataKey="mrrClosed" name="MRR Closed" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="backworkClosed" name="Backwork" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* New Clients Trend */}
              <Card className="bg-card border-border lg:col-span-2">
                <CardHeader>
                  <CardTitle className="text-foreground">New Clients Per Week</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="week" stroke="var(--muted-foreground)" fontSize={12} />
                      <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="newClients" name="New Clients" fill="var(--primary)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Entry Dialog */}
      <Dialog open={isEntryDialogOpen} onOpenChange={setIsEntryDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingEntry ? "Edit Week Data" : "Add Week Data"}
            </DialogTitle>
            <DialogDescription>
              Week of {formatDateDisplay(selectedWeekStart)} - {formatDateDisplay(formatDateISO(getSunday(new Date(selectedWeekStart + "T00:00:00"))))}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-4 sm:grid-cols-2">
              {kpiMetrics.map((metric) => (
                <div key={metric.key} className="space-y-2">
                  <Label htmlFor={metric.key} className="flex items-center gap-2">
                    <metric.icon className="h-4 w-4 text-muted-foreground" />
                    {metric.label}
                  </Label>
                  <Input
                    id={metric.key}
                    type="number"
                    min="0"
                    step={metric.type === "currency" ? "100" : "1"}
                    value={formData[metric.key as keyof FormData]}
                    onChange={(e) =>
                      setFormData({ ...formData, [metric.key]: parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
              ))}
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Add notes about this week..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEntryDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEntry}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Goals Dialog */}
      <Dialog open={isGoalsDialogOpen} onOpenChange={setIsGoalsDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Weekly Goals</DialogTitle>
            <DialogDescription>
              Set your target goals for each KPI metric.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-4 sm:grid-cols-2">
              {kpiMetrics.map((metric) => (
                <div key={metric.key} className="space-y-2">
                  <Label htmlFor={`goal-${metric.key}`} className="flex items-center gap-2">
                    <metric.icon className="h-4 w-4 text-muted-foreground" />
                    {metric.label}
                  </Label>
                  <Input
                    id={`goal-${metric.key}`}
                    type="number"
                    min="0"
                    step={metric.type === "currency" ? "100" : "1"}
                    value={goalsFormData[metric.key as keyof WeeklyKPIGoals]}
                    onChange={(e) =>
                      setGoalsFormData({
                        ...goalsFormData,
                        [metric.key]: parseFloat(e.target.value) || 0,
                      })
                    }
                  />
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsGoalsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveGoals}>Save Goals</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
