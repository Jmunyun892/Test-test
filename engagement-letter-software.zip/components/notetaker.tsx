"use client"

import { useState, useEffect, useMemo } from "react"
import { useEngagementStore } from "@/lib/engagement-store"
import type { Meeting } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Video,
  FileText,
  Sparkles,
  MessageSquare,
  Search,
  Calendar,
  Clock,
  Users,
  Play,
  ChevronLeft,
  Send,
  Zap,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  RefreshCw,
  Unplug,
  Cloud,
  CalendarDays,
} from "lucide-react"
import { toast } from "sonner"
import {
  hydrateZoomMeeting,
  isZoomOAuthConfigured,
  type SerializedZoomMeeting,
} from "@/lib/zoom-sync-client"
import {
  hydrateOutlookMeeting,
  isOutlookOAuthConfigured,
  type SerializedOutlookMeeting,
} from "@/lib/outlook-sync-client"

// Platform icons
const platformIcons: Record<string, string> = {
  zoom: "/images/zoom-icon.svg",
  teams: "/images/teams-icon.svg",
  google_meet: "/images/meet-icon.svg",
  other: "/images/video-icon.svg",
}

const platformLabels: Record<string, string> = {
  zoom: "Zoom",
  teams: "Teams",
  google_meet: "Google Meet",
  other: "Video Call",
}

interface MeetingCardProps {
  meeting: Meeting
  onSelect: (id: string) => void
}

function MeetingCardThumbnail({
  posterUrl,
  durationMin,
  hasRecording,
}: {
  posterUrl?: string
  durationMin: number
  hasRecording: boolean
}) {
  const isImagePoster =
    posterUrl &&
    (/\.(jpe?g|png|gif|webp)(\?|$)/i.test(posterUrl) || posterUrl.startsWith("/"))

  return (
    <div className="relative aspect-video w-full overflow-hidden bg-muted">
      {isImagePoster ? (
        <img
          src={posterUrl}
          alt=""
          className="absolute inset-0 h-full w-full object-cover pointer-events-none"
        />
      ) : null}
      <div
        className={
          isImagePoster
            ? "pointer-events-none absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent"
            : "absolute inset-0 bg-gradient-to-br from-primary/25 via-primary/10 to-muted"
        }
      />
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-background/90 shadow-md ring-1 ring-border">
          <Play className="h-7 w-7 text-primary translate-x-0.5" fill="currentColor" />
        </div>
      </div>
      <div className="pointer-events-none absolute bottom-2 right-2 flex gap-1">
        {hasRecording ? (
          <span className="rounded bg-black/75 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-white">
            Video
          </span>
        ) : null}
        <span className="rounded bg-black/75 px-2 py-0.5 text-xs font-medium text-white">
          {durationMin}m
        </span>
      </div>
    </div>
  )
}

function MeetingCard({ meeting, onSelect }: MeetingCardProps) {
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  return (
    <Card
      className="cursor-pointer overflow-hidden transition-all hover:border-primary/50 hover:shadow-md"
      onClick={() => onSelect(meeting.id)}
    >
      <MeetingCardThumbnail
        posterUrl={meeting.thumbnailUrl}
        durationMin={meeting.duration}
        hasRecording={Boolean(meeting.recordingUrl)}
      />
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="line-clamp-2 font-medium text-foreground leading-snug">
            {meeting.title}
          </h3>
          <Badge variant="outline" className="shrink-0 text-xs">
            {platformLabels[meeting.platform]}
          </Badge>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3 shrink-0" />
            {formatDate(meeting.date)}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3 shrink-0" />
            {formatTime(meeting.date)}
          </span>
          {meeting.participants.length > 0 && (
            <span className="flex items-center gap-1">
              <Users className="h-3 w-3 shrink-0" />
              {meeting.participants.length}
            </span>
          )}
        </div>

        <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
          {meeting.summary}
        </p>

        <div className="mt-3 flex flex-wrap gap-1">
          {meeting.tags.includes("outlook-calendar") && (
            <Badge variant="secondary" className="text-xs">
              Outlook
            </Badge>
          )}
          {meeting.zoomRecordingUuid && (
            <Badge className="text-xs bg-blue-600 hover:bg-blue-600">
              Zoom cloud
            </Badge>
          )}
          {meeting.recordingUrl && (
            <Badge variant="outline" className="text-xs">
              Video
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

interface MeetingDetailProps {
  meeting: Meeting
  onBack: () => void
}

function MeetingDetail({ meeting, onBack }: MeetingDetailProps) {
  const zoomConnection = useEngagementStore((s) => s.zoomConnection)
  const [proxyVideoSrc, setProxyVideoSrc] = useState<string | null>(null)
  const [streamLoading, setStreamLoading] = useState(false)
  const [streamError, setStreamError] = useState<string | null>(null)

  useEffect(() => {
    if (!meeting.recordingUrl) {
      setProxyVideoSrc(null)
      setStreamError(null)
      setStreamLoading(false)
      return
    }

    let cancelled = false
    setStreamLoading(true)
    setStreamError(null)
    setProxyVideoSrc(null)

    ;(async () => {
      try {
        const token = zoomConnection.connected
          ? zoomConnection.accessToken
          : undefined
        const res = await fetch("/api/zoom/recording/session", {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            ...(token ? { "x-zoom-token": token } : {}),
          },
          body: JSON.stringify({ recordingUrl: meeting.recordingUrl }),
        })
        const data = (await res.json().catch(() => ({}))) as {
          error?: string
          streamUrl?: string
        }
        if (!res.ok) {
          throw new Error(data.error || "Could not start in-app playback")
        }
        if (cancelled) return
        const src =
          typeof data.streamUrl === "string"
            ? data.streamUrl
            : `/api/zoom/recording/stream?_=${Date.now()}`
        setProxyVideoSrc(src)
      } catch (e) {
        if (!cancelled) {
          setStreamError(
            e instanceof Error ? e.message : "Could not prepare recording"
          )
        }
      } finally {
        if (!cancelled) setStreamLoading(false)
      }
    })()

    return () => {
      cancelled = true
    }
  }, [
    meeting.id,
    meeting.recordingUrl,
    zoomConnection.accessToken,
    zoomConnection.connected,
  ])

  const [activeTab, setActiveTab] = useState<"summary" | "transcript" | "ask">("summary")
  const [question, setQuestion] = useState("")
  const [chatHistory, setChatHistory] = useState<{ role: "user" | "assistant"; content: string }[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    })
  }

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  const handleAskQuestion = async () => {
    if (!question.trim()) return

    const userQuestion = question
    setQuestion("")
    setChatHistory((prev) => [...prev, { role: "user", content: userQuestion }])
    setIsLoading(true)

    // Simulate AI response based on transcript
    setTimeout(() => {
      const responses = [
        `Based on the transcript, ${meeting.participants[1] || "the client"} mentioned concerns about ${meeting.keyPoints[0]?.toLowerCase() || "their current processes"}. The discussion focused on addressing these issues through our proposed solutions.`,
        `Looking at the meeting notes, the main action items discussed were: ${meeting.actionItems.slice(0, 2).join(", ")}. These were prioritized based on the client's immediate needs.`,
        `From the conversation, it's clear that the client is interested in ${meeting.keyPoints[1]?.toLowerCase() || "improving their operations"}. They specifically asked about our approach to handling similar situations.`,
      ]
      const randomResponse = responses[Math.floor(Math.random() * responses.length)]
      setChatHistory((prev) => [...prev, { role: "assistant", content: randomResponse }])
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="border-b border-border p-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="mb-4 -ml-2 gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Back to Meetings
        </Button>

        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="font-heading text-2xl text-foreground">
              {meeting.title.toUpperCase()}
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {formatDate(meeting.date)}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {formatTime(meeting.date)} ({meeting.duration} min)
              </span>
              <Badge variant="outline">{platformLabels[meeting.platform]}</Badge>
              {meeting.zoomRecordingUuid && (
                <Badge className="bg-blue-600 hover:bg-blue-600">Zoom cloud</Badge>
              )}
            </div>
            <div className="mt-2 flex items-center gap-1 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{meeting.participants.join(", ")}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 shrink-0">
            {meeting.zoomJoinUrl && (
              <Button className="gap-2" asChild>
                <a href={meeting.zoomJoinUrl}>
                  <Video className="h-4 w-4" />
                  Join Zoom
                </a>
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {meeting.recordingUrl ? (
          <div className="mb-8 space-y-3">
            <h2 className="font-heading text-sm font-medium uppercase tracking-wide text-muted-foreground">
              Recording
            </h2>
            {streamLoading ? (
              <p className="text-sm text-muted-foreground">Preparing in-app playback…</p>
            ) : null}
            {streamError ? (
              <Card className="border-destructive/40 bg-destructive/5">
                <CardContent className="py-4 text-sm text-muted-foreground">
                  {streamError}
                </CardContent>
              </Card>
            ) : null}
            {proxyVideoSrc && !streamError ? (
              <video
                key={proxyVideoSrc}
                controls
                playsInline
                className="aspect-video w-full max-h-[min(52vh,560px)] rounded-lg border border-border bg-black object-contain shadow-sm"
                src={proxyVideoSrc}
                onError={() =>
                  setStreamError(
                    "Playback failed inside the app. Check that Zoom is connected and the recording URL is still valid."
                  )
                }
              />
            ) : null}
          </div>
        ) : null}

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)} className="flex min-h-0 flex-col">
          <TabsList className="w-fit">
            <TabsTrigger value="summary" className="gap-2">
              <Sparkles className="h-4 w-4" />
              AI Summary
            </TabsTrigger>
            <TabsTrigger value="transcript" className="gap-2">
              <FileText className="h-4 w-4" />
              Transcript
            </TabsTrigger>
            <TabsTrigger value="ask" className="gap-2">
              <MessageSquare className="h-4 w-4" />
              Ask Propel
            </TabsTrigger>
          </TabsList>

          <TabsContent value="summary" className="flex-1 overflow-auto mt-6">
            <div className="grid gap-6 lg:grid-cols-3">
              {/* Summary */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Sparkles className="h-5 w-5 text-primary" />
                    Meeting Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed text-foreground">
                    {meeting.summary}
                  </p>
                </CardContent>
              </Card>

              {/* Client */}
              {meeting.clientName && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Client</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm font-medium text-foreground">
                      {meeting.clientName}
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Key Points */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Lightbulb className="h-5 w-5 text-amber-400" />
                    Key Points
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {meeting.keyPoints.map((point, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <ArrowRight className="h-4 w-4 shrink-0 text-primary mt-0.5" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Action Items */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                    Action Items
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {meeting.actionItems.map((item, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="transcript" className="flex-1 overflow-hidden mt-6">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <FileText className="h-5 w-5" />
                  Full Transcript
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <ScrollArea className="h-[500px] pr-4">
                  <div className="space-y-4">
                    {meeting.transcript.map((segment, index) => (
                      <div key={index} className="flex gap-4">
                        <span className="shrink-0 text-xs text-muted-foreground font-mono w-12">
                          {segment.timestamp}
                        </span>
                        <div>
                          <p className="text-sm font-medium text-primary">
                            {segment.speaker}
                          </p>
                          <p className="text-sm text-foreground mt-1">
                            {segment.text}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ask" className="flex-1 overflow-hidden mt-6">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Zap className="h-5 w-5 text-primary" />
                  Ask Propel AI
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Ask questions about this meeting and get AI-powered answers based on the transcript.
                </p>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col overflow-hidden">
                {/* Chat History */}
                <ScrollArea className="flex-1 pr-4 mb-4">
                  {chatHistory.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center text-center py-12">
                      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
                        <MessageSquare className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="font-medium text-foreground mb-2">
                        Ask anything about this meeting
                      </h3>
                      <p className="text-sm text-muted-foreground max-w-sm">
                        Try questions like &ldquo;What were the main concerns?&rdquo; or &ldquo;What did the client say about pricing?&rdquo;
                      </p>
                      <div className="mt-6 flex flex-wrap justify-center gap-2">
                        {[
                          "What were the key takeaways?",
                          "What action items were discussed?",
                          "What concerns did the client raise?",
                        ].map((suggestion) => (
                          <Button
                            key={suggestion}
                            variant="outline"
                            size="sm"
                            onClick={() => setQuestion(suggestion)}
                            className="text-xs"
                          >
                            {suggestion}
                          </Button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {chatHistory.map((msg, index) => (
                        <div
                          key={index}
                          className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg px-4 py-2 ${
                              msg.role === "user"
                                ? "bg-primary text-primary-foreground"
                                : "bg-secondary text-secondary-foreground"
                            }`}
                          >
                            <p className="text-sm">{msg.content}</p>
                          </div>
                        </div>
                      ))}
                      {isLoading && (
                        <div className="flex justify-start">
                          <div className="bg-secondary rounded-lg px-4 py-2">
                            <div className="flex gap-1">
                              <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0ms" }} />
                              <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
                              <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </ScrollArea>

                {/* Input */}
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask a question about this meeting..."
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAskQuestion()}
                  />
                  <Button onClick={handleAskQuestion} disabled={!question.trim() || isLoading}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export function Notetaker() {
  const [mounted, setMounted] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [isSyncing, setIsSyncing] = useState(false)
  const [isDisconnecting, setIsDisconnecting] = useState(false)
  const [isOutlookSyncing, setIsOutlookSyncing] = useState(false)
  const {
    meetings,
    selectedMeetingId,
    setSelectedMeeting,
    zoomConnection,
    setZoomConnection,
    clearZoomConnection,
    upsertZoomMeetings,
    outlookConnection,
    setOutlookConnection,
    clearOutlookConnection,
    upsertOutlookMeetings,
  } = useEngagementStore()

  useEffect(() => {
    setMounted(true)
  }, [])

  const selectedMeeting = useMemo(() => {
    if (!mounted || !selectedMeetingId) return null
    return meetings.find((m) => m.id === selectedMeetingId) || null
  }, [mounted, meetings, selectedMeetingId])

  const filteredMeetings = useMemo(() => {
    if (!mounted) return []
    return meetings
      .filter((meeting) => {
        const query = searchQuery.toLowerCase()
        return (
          meeting.title.toLowerCase().includes(query) ||
          meeting.clientName?.toLowerCase().includes(query) ||
          meeting.tags.some((tag) => tag.toLowerCase().includes(query)) ||
          meeting.summary.toLowerCase().includes(query)
        )
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }, [mounted, meetings, searchQuery])

  if (!mounted) {
    return (
      <div className="flex h-full items-center justify-center">
        <p className="text-muted-foreground">Loading meetings...</p>
      </div>
    )
  }

  if (selectedMeeting) {
    return (
      <MeetingDetail
        meeting={selectedMeeting}
        onBack={() => setSelectedMeeting(null)}
      />
    )
  }

  return (
    <div className="flex h-full flex-col overflow-hidden p-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="font-heading text-3xl text-foreground">NOTETAKER</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Calendar (Outlook), Zoom cloud recordings, and AI notes
        </p>
      </div>

      {/* Outlook calendar — best source for start times and Zoom links in invites */}
      {!outlookConnection.connected ? (
        <Card className="mb-4 border-sky-500/25 bg-sky-500/5">
          <CardContent className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-sky-600">
                <CalendarDays className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Connect Outlook calendar</h3>
                <p className="text-sm text-muted-foreground">
                  Read meetings from Microsoft 365 / Outlook. We scan invite body and location for Zoom links, then remind you ~5 minutes before (while this app is open).
                </p>
                {!isOutlookOAuthConfigured() && (
                  <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
                    Register an app in{" "}
                    <a
                      className="underline"
                      href="https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Microsoft Entra
                    </a>
                    , add redirect{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      NEXT_PUBLIC_MICROSOFT_REDIRECT_URI
                    </code>
                    , API permissions:{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      Calendars.Read
                    </code>
                    ,{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      User.Read
                    </code>
                    ,{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      offline_access
                    </code>
                    . Set{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      NEXT_PUBLIC_MICROSOFT_CLIENT_ID
                    </code>{" "}
                    and{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      MICROSOFT_CLIENT_SECRET
                    </code>
                    .
                  </p>
                )}
              </div>
            </div>
            <Button
              className="gap-2 shrink-0 bg-sky-600 hover:bg-sky-600/90"
              disabled={!isOutlookOAuthConfigured()}
              onClick={() => {
                window.location.href = "/api/outlook/authorize"
              }}
            >
              <CalendarDays className="h-4 w-4" />
              Connect Outlook
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="mb-4 border-sky-500/25 bg-sky-500/5">
          <CardContent className="flex flex-col gap-4 p-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-sky-600">
                <CalendarDays className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Outlook connected</h3>
                <p className="text-sm text-muted-foreground">
                  {outlookConnection.displayName || outlookConnection.email || "Calendar"}
                  {outlookConnection.email && outlookConnection.displayName
                    ? ` · ${outlookConnection.email}`
                    : ""}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                className="gap-2"
                disabled={isOutlookSyncing}
                onClick={async () => {
                  if (!outlookConnection.accessToken) {
                    toast.error("Missing Outlook token. Connect again.")
                    return
                  }
                  setIsOutlookSyncing(true)
                  try {
                    const res = await fetch("/api/outlook/calendar/sync", {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        "x-outlook-token": outlookConnection.accessToken,
                        ...(outlookConnection.refreshToken
                          ? { "x-outlook-refresh-token": outlookConnection.refreshToken }
                          : {}),
                      },
                      body: JSON.stringify({
                        daysBack: 14,
                        daysAhead: 90,
                        accessToken: outlookConnection.accessToken,
                        refreshToken: outlookConnection.refreshToken,
                      }),
                    })
                    const data = await res.json()
                    if (!res.ok) {
                      if (data.needsReauth) {
                        clearOutlookConnection()
                        toast.error("Outlook session expired. Connect again.")
                      } else {
                        toast.error(data.error || "Outlook sync failed")
                      }
                      return
                    }
                    if (data.newTokens) {
                      setOutlookConnection({
                        ...outlookConnection,
                        accessToken: data.newTokens.accessToken,
                        refreshToken:
                          data.newTokens.refreshToken || outlookConnection.refreshToken,
                        expiresAt: data.newTokens.expiresAt,
                        connected: true,
                      })
                    }
                    const imported = (data.meetings as SerializedOutlookMeeting[]).map(
                      hydrateOutlookMeeting
                    )
                    upsertOutlookMeetings(imported)
                    toast.success(
                      `Imported ${imported.length} calendar event${imported.length === 1 ? "" : "s"} from Outlook`
                    )
                  } catch {
                    toast.error("Could not sync Outlook calendar.")
                  } finally {
                    setIsOutlookSyncing(false)
                  }
                }}
              >
                <RefreshCw
                  className={`h-4 w-4 ${isOutlookSyncing ? "animate-spin" : ""}`}
                />
                {isOutlookSyncing ? "Syncing…" : "Sync calendar"}
              </Button>
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => {
                  clearOutlookConnection()
                  toast.message("Outlook disconnected on this device.")
                }}
              >
                <Unplug className="h-4 w-4" />
                Disconnect
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Zoom integration */}
      {!zoomConnection.connected ? (
        <Card className="mb-6 border-primary/30 bg-primary/5">
          <CardContent className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-600">
                <Video className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Connect Zoom</h3>
                <p className="text-sm text-muted-foreground">
                  Import cloud recordings and transcripts from the last 60 days into your notetaker.
                </p>
                {!isZoomOAuthConfigured() && (
                  <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
                    Set{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      NEXT_PUBLIC_ZOOM_CLIENT_ID
                    </code>
                    ,{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      ZOOM_CLIENT_SECRET
                    </code>
                    , and{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      NEXT_PUBLIC_ZOOM_REDIRECT_URI
                    </code>{" "}
                    to match your Zoom OAuth app (same scopes as{" "}
                    <code className="rounded bg-muted px-1 py-0.5 text-[10px]">
                      ZOOM_OAUTH_SCOPES
                    </code>
                    ).
                  </p>
                )}
              </div>
            </div>
            <Button
              className="gap-2 shrink-0"
              disabled={!isZoomOAuthConfigured()}
              onClick={() => {
                window.location.href = "/api/zoom/authorize"
              }}
            >
              <Zap className="h-4 w-4" />
              Connect Zoom
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="mb-6 border-blue-500/25 bg-blue-500/5">
          <CardContent className="flex flex-col gap-4 p-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-blue-600">
                <Cloud className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Zoom connected</h3>
                <p className="text-sm text-muted-foreground">
                  {zoomConnection.displayName || zoomConnection.email || "Your Zoom account"}
                  {zoomConnection.email && zoomConnection.displayName
                    ? ` · ${zoomConnection.email}`
                    : null}
                </p>
                {zoomConnection.expiresAt && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    Access token refreshes automatically; session data is stored in this browser.
                  </p>
                )}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                className="gap-2"
                disabled={isSyncing}
                onClick={async () => {
                  if (!zoomConnection.accessToken) {
                    toast.error("Missing Zoom access token. Connect again.")
                    return
                  }
                  setIsSyncing(true)
                  try {
                    const res = await fetch("/api/zoom/sync", {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        "x-zoom-token": zoomConnection.accessToken,
                        ...(zoomConnection.refreshToken
                          ? { "x-zoom-refresh-token": zoomConnection.refreshToken }
                          : {}),
                      },
                      body: JSON.stringify({
                        daysBack: 60,
                        accessToken: zoomConnection.accessToken,
                        refreshToken: zoomConnection.refreshToken,
                      }),
                    })
                    const data = await res.json()
                    if (!res.ok) {
                      if (data.needsReauth) {
                        clearZoomConnection()
                        toast.error("Zoom session expired. Please connect again.")
                      } else {
                        toast.error(data.error || "Sync failed")
                      }
                      return
                    }
                    if (data.newTokens) {
                      setZoomConnection({
                        ...zoomConnection,
                        accessToken: data.newTokens.accessToken,
                        refreshToken: data.newTokens.refreshToken,
                        expiresAt: data.newTokens.expiresAt,
                        connected: true,
                      })
                    }
                    const imported = (data.meetings as SerializedZoomMeeting[]).map(
                      hydrateZoomMeeting
                    )
                    upsertZoomMeetings(imported)
                    toast.success(
                      `Synced ${imported.length} recording${imported.length === 1 ? "" : "s"} from Zoom`
                    )
                  } catch {
                    toast.error("Could not reach the server to sync Zoom.")
                  } finally {
                    setIsSyncing(false)
                  }
                }}
              >
                <RefreshCw
                  className={`h-4 w-4 ${isSyncing ? "animate-spin" : ""}`}
                />
                {isSyncing ? "Syncing…" : "Sync cloud recordings"}
              </Button>
              <Button
                variant="outline"
                className="gap-2"
                disabled={isDisconnecting}
                onClick={async () => {
                  setIsDisconnecting(true)
                  try {
                    if (zoomConnection.accessToken) {
                      await fetch("/api/zoom/disconnect", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          accessToken: zoomConnection.accessToken,
                        }),
                      })
                    }
                  } catch {
                    /* still clear locally */
                  } finally {
                    clearZoomConnection()
                    setIsDisconnecting(false)
                    toast.message("Zoom disconnected on this device.")
                  }
                }}
              >
                <Unplug className="h-4 w-4" />
                Disconnect
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search meetings by title, client, or tag..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <p className="text-2xl font-bold text-foreground">{meetings.length}</p>
            <p className="text-xs text-muted-foreground">Total Meetings</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-2xl font-bold text-foreground">
              {Math.round(meetings.reduce((sum, m) => sum + m.duration, 0) / 60)}h
            </p>
            <p className="text-xs text-muted-foreground">Hours Recorded</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-2xl font-bold text-foreground">
              {meetings.reduce((sum, m) => sum + m.actionItems.length, 0)}
            </p>
            <p className="text-xs text-muted-foreground">Action Items</p>
          </CardContent>
        </Card>
      </div>

      {/* Meetings grid */}
      <div className="flex-1 overflow-hidden">
        <h2 className="font-heading text-lg text-muted-foreground mb-4">
          Meetings
        </h2>
        <ScrollArea className="h-[calc(100%-2rem)]">
          <div className="grid grid-cols-1 gap-4 pr-4 pb-4 sm:grid-cols-2 xl:grid-cols-3">
            {filteredMeetings.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
                <Video className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No meetings found</p>
              </div>
            ) : (
              filteredMeetings.map((meeting) => (
                <MeetingCard
                  key={meeting.id}
                  meeting={meeting}
                  onSelect={setSelectedMeeting}
                />
              ))
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  )
}
