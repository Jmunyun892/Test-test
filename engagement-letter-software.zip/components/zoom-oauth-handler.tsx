"use client"

import { useEffect, useRef } from "react"
import { toast } from "sonner"
import { useEngagementStore } from "@/lib/engagement-store"
import type { ZoomConnection } from "@/lib/types"

function decodeZoomCallbackPayload(data: string): {
  accessToken: string
  refreshToken: string
  expiresAt: number
  userId: string
  email: string
  displayName: string
  accountId: string
} {
  const binary = atob(data)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i)
  }
  const text = new TextDecoder().decode(bytes)
  return JSON.parse(text) as ReturnType<typeof decodeZoomCallbackPayload>
}

/** Handles OAuth redirect query params and clears them from the address bar. */
export function ZoomOAuthHandler() {
  const setZoomConnection = useEngagementStore((s) => s.setZoomConnection)
  const setView = useEngagementStore((s) => s.setView)
  const handled = useRef(false)

  useEffect(() => {
    if (handled.current || typeof window === "undefined") return

    const params = new URLSearchParams(window.location.search)
    const zoomConnected = params.get("zoom_connected")
    const zoomError = params.get("zoom_error")
    const data = params.get("data")

    if (!zoomConnected && !zoomError) return

    handled.current = true

    const cleanUrl = () => {
      window.history.replaceState({}, "", window.location.pathname)
    }

    if (zoomError) {
      toast.error(`Zoom connection failed: ${decodeURIComponent(zoomError)}`)
      cleanUrl()
      return
    }

    if (zoomConnected === "true" && data) {
      try {
        const payload = decodeZoomCallbackPayload(data)
        const connection: ZoomConnection = {
          connected: true,
          accessToken: payload.accessToken,
          refreshToken: payload.refreshToken,
          expiresAt: payload.expiresAt,
          userId: payload.userId,
          email: payload.email,
          displayName: payload.displayName,
          accountId: payload.accountId,
          connectedAt: new Date().toISOString(),
        }
        setZoomConnection(connection)
        setView("notetaker")
        toast.success("Zoom connected. You can sync cloud recordings from the Notetaker.")
      } catch {
        toast.error("Could not read Zoom connection data. Try connecting again.")
      }
      cleanUrl()
    }
  }, [setZoomConnection, setView])

  return null
}
