"use client"

import { useState, useMemo, useEffect } from "react"
import {
  Search,
  Filter,
  MoreHorizontal,
  Eye,
  Edit2,
  Trash2,
  Send,
  ChevronDown,
  Plus,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useEngagementStore } from "@/lib/engagement-store"
import type { LetterStatus } from "@/lib/types"
import { cn } from "@/lib/utils"

const statusColors: Record<string, string> = {
  draft: "bg-amber-400/20 text-amber-400",
  sent: "bg-blue-400/20 text-blue-400",
  viewed: "bg-purple-400/20 text-purple-400",
  won: "bg-emerald-400/20 text-emerald-400",
  signed: "bg-emerald-400/20 text-emerald-400", // Legacy support
  expired: "bg-chart-4/20 text-chart-4",
  rejected: "bg-destructive/20 text-destructive",
}

const statusLabels: Record<string, string> = {
  draft: "Draft",
  sent: "Sent",
  viewed: "Viewed",
  won: "Won",
  signed: "Won", // Legacy support
  expired: "Expired",
  rejected: "Rejected",
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

function formatDate(date: Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

export function LettersTable() {
  const [mounted, setMounted] = useState(false)
  const {
    letters,
    setView,
    setSelectedLetter,
    deleteLetter,
    updateLetter,
  } = useEngagementStore()

  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [serviceFilter, setServiceFilter] = useState<string>("all")

  useEffect(() => {
    setMounted(true)
  }, [])

  const serviceTypes = useMemo(() => {
    if (!mounted) return []
    const types = new Set(letters.map((l) => l.serviceType))
    return Array.from(types)
  }, [letters])

  const filteredLetters = useMemo(() => {
    return letters.filter((letter) => {
      const matchesSearch =
        searchQuery === "" ||
        letter.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        letter.clientName.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesStatus =
        statusFilter === "all" || letter.status === statusFilter

      const matchesService =
        serviceFilter === "all" || letter.serviceType === serviceFilter

      return matchesSearch && matchesStatus && matchesService
    })
  }, [letters, searchQuery, statusFilter, serviceFilter])

  const handleView = (id: string) => {
    setSelectedLetter(id)
    setView("detail")
  }

  const handleEdit = (id: string) => {
    setSelectedLetter(id)
    setView("editor")
  }

  const handleSend = (id: string) => {
    updateLetter(id, {
      status: "sent",
      sentAt: new Date(),
    })
  }

  const handleDelete = (id: string) => {
    deleteLetter(id)
  }

  const handleNewLetter = () => {
    setSelectedLetter(null)
    setView("editor")
  }

  if (!mounted) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-muted-foreground">Loading letters...</div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-heading text-3xl text-foreground">
            ENGAGEMENT LETTERS
          </h1>
          <p className="text-sm text-muted-foreground">
            Manage and track all your engagement letters
          </p>
        </div>
        <Button onClick={handleNewLetter} className="gap-2">
          <Plus className="h-4 w-4" />
          New Letter
        </Button>
      </div>

      {/* Filters */}
      <Card className="mb-6 bg-card border-border p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search letters..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-secondary border-border"
            />
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Status: {statusFilter === "all" ? "All" : statusLabels[statusFilter]}
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setStatusFilter("all")}>
                All Statuses
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {Object.entries(statusLabels).map(([value, label]) => (
                <DropdownMenuItem
                  key={value}
                  onClick={() => setStatusFilter(value as LetterStatus)}
                >
                  {label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                Service: {serviceFilter === "all" ? "All" : serviceFilter}
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setServiceFilter("all")}>
                All Services
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {serviceTypes.map((type) => (
                <DropdownMenuItem
                  key={type}
                  onClick={() => setServiceFilter(type)}
                >
                  {type}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </Card>

      {/* Table */}
      <Card className="bg-card border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Letter
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Client
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Service
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Status
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Value
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Created
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredLetters.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-4 py-12 text-center text-muted-foreground"
                  >
                    No engagement letters found
                  </td>
                </tr>
              ) : (
                filteredLetters.map((letter) => (
                  <tr
                    key={letter.id}
                    className="transition-colors hover:bg-secondary/30"
                  >
                    <td className="px-4 py-4">
                      <button
                        onClick={() => handleView(letter.id)}
                        className="text-left"
                      >
                        <p className="font-medium text-foreground hover:text-primary transition-colors">
                          {letter.title}
                        </p>
                      </button>
                    </td>
                    <td className="px-4 py-4">
                      <p className="text-sm text-foreground">
                        {letter.clientName}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {letter.clientEmail}
                      </p>
                    </td>
                    <td className="px-4 py-4">
                      <span className="inline-flex items-center rounded-md bg-secondary px-2 py-1 text-xs font-medium text-secondary-foreground">
                        {letter.serviceType}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span
                        className={cn(
                          "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                          statusColors[letter.status]
                        )}
                      >
                        {statusLabels[letter.status]}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm font-medium text-foreground">
                      {formatCurrency(letter.value)}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted-foreground">
                      {formatDate(letter.createdAt)}
                    </td>
                    <td className="px-4 py-4 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleView(letter.id)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEdit(letter.id)}>
                            <Edit2 className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          {letter.status === "draft" && (
                            <DropdownMenuItem
                              onClick={() => handleSend(letter.id)}
                            >
                              <Send className="mr-2 h-4 w-4" />
                              Send
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDelete(letter.id)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="flex items-center justify-between border-t border-border px-4 py-3">
          <p className="text-sm text-muted-foreground">
            Showing {filteredLetters.length} of {letters.length} letters
          </p>
        </div>
      </Card>
    </div>
  )
}
