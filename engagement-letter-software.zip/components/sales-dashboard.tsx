"use client"

import { useMemo, useState, useEffect } from "react"
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Target,
  Clock,
  Users,
  BarChart3,
  PieChart,
  Plus,
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  Edit,
  Trash2,
  Eye,
} from "lucide-react"
import { useEngagementStore } from "@/lib/engagement-store"
import type { SaleStage, SalesRecord } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPie,
  Pie,
  Cell,
  AreaChart,
  Area,
  Legend,
  Funnel,
  FunnelChart,
  LabelList,
} from "recharts"

const stageColors: Record<SaleStage, string> = {
  lead: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  qualified: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  proposal: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  negotiation: "bg-primary/20 text-primary border-primary/30",
  closed_won: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  closed_lost: "bg-red-500/20 text-red-400 border-red-500/30",
}

const stageLabels: Record<SaleStage, string> = {
  lead: "Lead",
  qualified: "Qualified",
  proposal: "Proposal",
  negotiation: "Negotiation",
  closed_won: "Won",
  closed_lost: "Lost",
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

interface SalesFormData {
  clientName: string
  contactEmail: string
  serviceType: string
  estimatedValue: string
  stage: SaleStage
  probability: string
  source: string
  assignedTo: string
  expectedCloseDate: string
  notes: string
}

const defaultFormData: SalesFormData = {
  clientName: "",
  contactEmail: "",
  serviceType: "",
  estimatedValue: "",
  stage: "lead",
  probability: "20",
  source: "",
  assignedTo: "",
  expectedCloseDate: "",
  notes: "",
}

export function SalesDashboard() {
  const [mounted, setMounted] = useState(false)
  const {
    getSalesKPIData,
    salesRecords,
    addSalesRecord,
    updateSalesRecord,
    deleteSalesRecord,
  } = useEngagementStore()

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingRecord, setEditingRecord] = useState<SalesRecord | null>(null)
  const [formData, setFormData] = useState<SalesFormData>(defaultFormData)
  const [activeTab, setActiveTab] = useState<"overview" | "pipeline" | "analytics">("overview")

  useEffect(() => {
    setMounted(true)
  }, [])

  // Only compute sales data after mounting to avoid hydration mismatch
  const salesData = useMemo(() => {
    if (!mounted) return null
    return getSalesKPIData()
  }, [mounted, salesRecords, getSalesKPIData])

  const handleOpenDialog = (record?: SalesRecord) => {
    if (record) {
      setEditingRecord(record)
      setFormData({
        clientName: record.clientName,
        contactEmail: record.contactEmail,
        serviceType: record.serviceType,
        estimatedValue: record.estimatedValue.toString(),
        stage: record.stage,
        probability: record.probability.toString(),
        source: record.source,
        assignedTo: record.assignedTo,
        expectedCloseDate: new Date(record.expectedCloseDate).toISOString().split("T")[0],
        notes: record.notes,
      })
    } else {
      setEditingRecord(null)
      setFormData(defaultFormData)
    }
    setIsDialogOpen(true)
  }

  const handleSave = () => {
    const recordData = {
      clientName: formData.clientName,
      contactEmail: formData.contactEmail,
      serviceType: formData.serviceType,
      estimatedValue: parseFloat(formData.estimatedValue) || 0,
      stage: formData.stage,
      probability: parseInt(formData.probability) || 0,
      source: formData.source,
      assignedTo: formData.assignedTo,
      expectedCloseDate: new Date(formData.expectedCloseDate),
      notes: formData.notes,
    }

    if (editingRecord) {
      updateSalesRecord(editingRecord.id, recordData)
    } else {
      addSalesRecord(recordData)
    }
    setIsDialogOpen(false)
    setFormData(defaultFormData)
    setEditingRecord(null)
  }

  const handleStageChange = (id: string, newStage: SaleStage) => {
    const probabilities: Record<SaleStage, number> = {
      lead: 20,
      qualified: 40,
      proposal: 60,
      negotiation: 75,
      closed_won: 100,
      closed_lost: 0,
    }
    updateSalesRecord(id, {
      stage: newStage,
      probability: probabilities[newStage],
      ...(newStage === "closed_won" || newStage === "closed_lost"
        ? { closedAt: new Date() }
        : {}),
    })
  }

  if (!mounted || !salesData) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <div className="text-muted-foreground">Loading sales data...</div>
      </div>
    )
  }

  const kpiCards = [
    {
      title: "Pipeline Value",
      value: formatCurrency(salesData.totalPipeline),
      subtitle: `${salesData.dealsInPipeline} deals`,
      icon: Target,
      trend: "+12%",
      trendUp: true,
    },
    {
      title: "Won Revenue",
      value: formatCurrency(salesData.wonRevenue),
      subtitle: `${salesData.dealsWon} deals closed`,
      icon: TrendingUp,
      trend: "+8%",
      trendUp: true,
    },
    {
      title: "Lost Revenue",
      value: formatCurrency(salesData.lostRevenue),
      subtitle: `${salesData.dealsLost} deals lost`,
      icon: TrendingDown,
      trend: "-5%",
      trendUp: false,
    },
    {
      title: "Win Rate",
      value: `${salesData.winRate}%`,
      subtitle: "Closed deals ratio",
      icon: BarChart3,
      trend: "+2.5%",
      trendUp: true,
    },
    {
      title: "Avg Deal Size",
      value: formatCurrency(salesData.avgDealSize),
      subtitle: "Per closed deal",
      icon: DollarSign,
      trend: "+15%",
      trendUp: true,
    },
    {
      title: "Sales Cycle",
      value: `${salesData.avgSalesCycle} days`,
      subtitle: "Avg time to close",
      icon: Clock,
      trend: "-3 days",
      trendUp: true,
    },
  ]

  const funnelData = salesData.salesByStage
    .filter((s) => !["Won", "Lost"].includes(s.stage))
    .map((s) => ({
      name: s.stage,
      value: s.count,
      amount: s.value,
      fill: s.fill,
    }))

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-heading text-3xl text-foreground">SALES TRACKER</h1>
          <p className="text-sm text-muted-foreground">
            Monitor your sales pipeline and performance metrics
          </p>
        </div>
        <Button onClick={() => handleOpenDialog()} className="gap-2">
          <Plus className="h-4 w-4" />
          New Deal
        </Button>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6 flex gap-2 border-b border-border">
        {[
          { id: "overview", label: "Overview" },
          { id: "pipeline", label: "Pipeline" },
          { id: "analytics", label: "Analytics" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? "border-b-2 border-primary text-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "overview" && (
        <>
          {/* KPI Cards */}
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            {kpiCards.map((kpi) => (
              <Card key={kpi.title} className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="rounded-lg bg-secondary p-2">
                      <kpi.icon className="h-4 w-4 text-primary" />
                    </div>
                    <div
                      className={`flex items-center gap-1 text-xs ${
                        kpi.trendUp ? "text-emerald-400" : "text-red-400"
                      }`}
                    >
                      {kpi.trendUp ? (
                        <ArrowUpRight className="h-3 w-3" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3" />
                      )}
                      {kpi.trend}
                    </div>
                  </div>
                  <div className="mt-3">
                    <p className="text-xl font-semibold text-foreground">{kpi.value}</p>
                    <p className="text-xs text-muted-foreground">{kpi.title}</p>
                    <p className="mt-1 text-xs text-muted-foreground/70">{kpi.subtitle}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Charts Row */}
          <div className="mb-6 grid gap-6 lg:grid-cols-2">
            {/* Revenue Trend */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={salesData.salesByMonth}>
                      <defs>
                        <linearGradient id="wonGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--chart-2)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="var(--chart-2)" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="pipelineGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--chart-1)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="var(--chart-1)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis
                        dataKey="month"
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                      />
                      <YAxis
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                        tickFormatter={(v) => `$${v / 1000}k`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                          borderRadius: "8px",
                        }}
                        formatter={(value: number) => formatCurrency(value)}
                      />
                      <Legend />
                      <Area
                        type="monotone"
                        dataKey="won"
                        name="Won"
                        stroke="var(--chart-2)"
                        fill="url(#wonGradient)"
                        strokeWidth={2}
                      />
                      <Area
                        type="monotone"
                        dataKey="pipeline"
                        name="Pipeline"
                        stroke="var(--chart-1)"
                        fill="url(#pipelineGradient)"
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Pipeline by Stage */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Pipeline by Stage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salesData.salesByStage} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis
                        type="number"
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                        tickFormatter={(v) => `$${v / 1000}k`}
                      />
                      <YAxis
                        type="category"
                        dataKey="stage"
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                        width={80}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--card)",
                          border: "1px solid var(--border)",
                          borderRadius: "8px",
                        }}
                        formatter={(value: number, name: string) => [
                          formatCurrency(value),
                          name,
                        ]}
                      />
                      <Bar dataKey="value" name="Value" radius={[0, 4, 4, 0]}>
                        {salesData.salesByStage.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Deals & Team Performance */}
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Recent Deals */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Recent Deals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {salesData.recentDeals.map((deal) => (
                    <div
                      key={deal.id}
                      className="flex items-center justify-between rounded-lg bg-secondary/50 p-3"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="truncate text-sm font-medium text-foreground">
                          {deal.client}
                        </p>
                        <p className="text-xs text-muted-foreground">{deal.date}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge
                          variant="outline"
                          className={stageColors[deal.stage]}
                        >
                          {stageLabels[deal.stage]}
                        </Badge>
                        <span className="text-sm font-medium text-foreground">
                          {formatCurrency(deal.value)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Team Performance */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Team Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {salesData.salesByRep.map((rep) => (
                    <div key={rep.rep} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-xs font-medium text-primary">
                            {rep.rep
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-foreground">
                              {rep.rep}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {rep.deals} deals
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-emerald-400">
                            {formatCurrency(rep.won)}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatCurrency(rep.pipeline)} pipeline
                          </p>
                        </div>
                      </div>
                      <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
                        <div
                          className="bg-emerald-500"
                          style={{
                            width: `${
                              (rep.won / (rep.won + rep.pipeline || 1)) * 100
                            }%`,
                          }}
                        />
                        <div
                          className="bg-primary/50"
                          style={{
                            width: `${
                              (rep.pipeline / (rep.won + rep.pipeline || 1)) * 100
                            }%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {activeTab === "pipeline" && (
        <div className="space-y-6">
          {/* Pipeline Table */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">All Deals</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{salesRecords.length} deals</Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Client
                      </th>
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Service
                      </th>
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Value
                      </th>
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Stage
                      </th>
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Probability
                      </th>
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Owner
                      </th>
                      <th className="pb-3 text-left text-xs font-medium uppercase text-muted-foreground">
                        Expected Close
                      </th>
                      <th className="pb-3 text-right text-xs font-medium uppercase text-muted-foreground">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {salesRecords.map((record) => (
                      <tr
                        key={record.id}
                        className="border-b border-border/50 last:border-0"
                      >
                        <td className="py-3">
                          <div>
                            <p className="text-sm font-medium text-foreground">
                              {record.clientName}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {record.contactEmail}
                            </p>
                          </div>
                        </td>
                        <td className="py-3 text-sm text-foreground">
                          {record.serviceType}
                        </td>
                        <td className="py-3 text-sm font-medium text-foreground">
                          {formatCurrency(record.estimatedValue)}
                        </td>
                        <td className="py-3">
                          <Select
                            value={record.stage}
                            onValueChange={(value: SaleStage) =>
                              handleStageChange(record.id, value)
                            }
                          >
                            <SelectTrigger className="h-7 w-28 border-none bg-transparent p-0">
                              <Badge
                                variant="outline"
                                className={stageColors[record.stage]}
                              >
                                {stageLabels[record.stage]}
                              </Badge>
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(stageLabels).map(([value, label]) => (
                                <SelectItem key={value} value={value}>
                                  {label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <div className="h-2 w-16 overflow-hidden rounded-full bg-secondary">
                              <div
                                className="h-full bg-primary"
                                style={{ width: `${record.probability}%` }}
                              />
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {record.probability}%
                            </span>
                          </div>
                        </td>
                        <td className="py-3 text-sm text-foreground">
                          {record.assignedTo}
                        </td>
                        <td className="py-3 text-sm text-muted-foreground">
                          {new Date(record.expectedCloseDate).toLocaleDateString(
                            "en-US",
                            { month: "short", day: "numeric", year: "numeric" }
                          )}
                        </td>
                        <td className="py-3 text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleOpenDialog(record)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => deleteSalesRecord(record.id)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "analytics" && (
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Source Analysis */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Deals by Source</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPie>
                    <Pie
                      data={salesData.salesBySource}
                      dataKey="value"
                      nameKey="source"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      label={({ name, percent }) =>
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {salesData.salesBySource.map((_, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={`var(--chart-${(index % 5) + 1})`}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "1px solid var(--border)",
                        borderRadius: "8px",
                      }}
                      formatter={(value: number) => formatCurrency(value)}
                    />
                  </RechartsPie>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 space-y-2">
                {salesData.salesBySource.map((source, index) => (
                  <div
                    key={source.source}
                    className="flex items-center justify-between text-sm"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="h-3 w-3 rounded-full"
                        style={{ backgroundColor: `var(--chart-${(index % 5) + 1})` }}
                      />
                      <span className="text-muted-foreground">{source.source}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-muted-foreground">{source.count} deals</span>
                      <span className="font-medium text-foreground">
                        {formatCurrency(source.value)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Win/Loss Analysis */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Win/Loss Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-6 grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-emerald-500/10 p-4">
                  <p className="text-2xl font-semibold text-emerald-400">
                    {salesData.dealsWon}
                  </p>
                  <p className="text-sm text-muted-foreground">Deals Won</p>
                  <p className="mt-1 text-lg font-medium text-emerald-400">
                    {formatCurrency(salesData.wonRevenue)}
                  </p>
                </div>
                <div className="rounded-lg bg-red-500/10 p-4">
                  <p className="text-2xl font-semibold text-red-400">
                    {salesData.dealsLost}
                  </p>
                  <p className="text-sm text-muted-foreground">Deals Lost</p>
                  <p className="mt-1 text-lg font-medium text-red-400">
                    {formatCurrency(salesData.lostRevenue)}
                  </p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Win Rate</span>
                    <span className="font-medium text-foreground">
                      {salesData.winRate}%
                    </span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full bg-emerald-500"
                      style={{ width: `${salesData.winRate}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Average Sales Cycle</span>
                    <span className="font-medium text-foreground">
                      {salesData.avgSalesCycle} days
                    </span>
                  </div>
                </div>
                <div>
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Average Deal Size</span>
                    <span className="font-medium text-foreground">
                      {formatCurrency(salesData.avgDealSize)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Revenue by Service Type */}
          <Card className="bg-card border-border lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Monthly Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={salesData.salesByMonth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="month"
                      stroke="var(--muted-foreground)"
                      fontSize={12}
                    />
                    <YAxis
                      stroke="var(--muted-foreground)"
                      fontSize={12}
                      tickFormatter={(v) => `$${v / 1000}k`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "1px solid var(--border)",
                        borderRadius: "8px",
                      }}
                      formatter={(value: number) => formatCurrency(value)}
                    />
                    <Legend />
                    <Bar
                      dataKey="won"
                      name="Won"
                      fill="var(--chart-2)"
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar
                      dataKey="lost"
                      name="Lost"
                      fill="var(--chart-4)"
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar
                      dataKey="pipeline"
                      name="Pipeline"
                      fill="var(--chart-1)"
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Add/Edit Deal Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingRecord ? "Edit Deal" : "Add New Deal"}
            </DialogTitle>
            <DialogDescription>
              {editingRecord ? "Update the deal details below." : "Enter the details for the new sales opportunity."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="clientName">Client Name</Label>
                <Input
                  id="clientName"
                  value={formData.clientName}
                  onChange={(e) =>
                    setFormData({ ...formData, clientName: e.target.value })
                  }
                  placeholder="Enter client name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Contact Email</Label>
                <Input
                  id="contactEmail"
                  type="email"
                  value={formData.contactEmail}
                  onChange={(e) =>
                    setFormData({ ...formData, contactEmail: e.target.value })
                  }
                  placeholder="email@example.com"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="serviceType">Service Type</Label>
                <Input
                  id="serviceType"
                  value={formData.serviceType}
                  onChange={(e) =>
                    setFormData({ ...formData, serviceType: e.target.value })
                  }
                  placeholder="e.g., Audit, Tax"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimatedValue">Estimated Value ($)</Label>
                <Input
                  id="estimatedValue"
                  type="number"
                  value={formData.estimatedValue}
                  onChange={(e) =>
                    setFormData({ ...formData, estimatedValue: e.target.value })
                  }
                  placeholder="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Stage</Label>
                <Select
                  value={formData.stage}
                  onValueChange={(value: SaleStage) =>
                    setFormData({ ...formData, stage: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(stageLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="probability">Probability (%)</Label>
                <Input
                  id="probability"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.probability}
                  onChange={(e) =>
                    setFormData({ ...formData, probability: e.target.value })
                  }
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="source">Source</Label>
                <Input
                  id="source"
                  value={formData.source}
                  onChange={(e) =>
                    setFormData({ ...formData, source: e.target.value })
                  }
                  placeholder="e.g., Referral, Website"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="assignedTo">Assigned To</Label>
                <Input
                  id="assignedTo"
                  value={formData.assignedTo}
                  onChange={(e) =>
                    setFormData({ ...formData, assignedTo: e.target.value })
                  }
                  placeholder="Sales rep name"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="expectedCloseDate">Expected Close Date</Label>
              <Input
                id="expectedCloseDate"
                type="date"
                value={formData.expectedCloseDate}
                onChange={(e) =>
                  setFormData({ ...formData, expectedCloseDate: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) =>
                  setFormData({ ...formData, notes: e.target.value })
                }
                placeholder="Add any additional notes..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              {editingRecord ? "Save Changes" : "Add Deal"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
