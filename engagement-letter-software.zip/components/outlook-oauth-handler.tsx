"use client"

import { useEffect, useRef } from "react"
import { toast } from "sonner"
import { useEngagementStore } from "@/lib/engagement-store"
import type { OutlookConnection } from "@/lib/types"

function decodePayload(data: string) {
  const binary = atob(data)
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i)
  return JSON.parse(new TextDecoder().decode(bytes)) as {
    accessToken: string
    refreshToken: string
    expiresAt: number
    userId: string
    email: string
    displayName: string
  }
}

export function OutlookOAuthHandler() {
  const setOutlookConnection = useEngagementStore((s) => s.setOutlookConnection)
  const setView = useEngagementStore((s) => s.setView)
  const handled = useRef(false)

  useEffect(() => {
    if (handled.current || typeof window === "undefined") return
    const params = new URLSearchParams(window.location.search)
    const ok = params.get("outlook_connected")
    const err = params.get("outlook_error")
    const data = params.get("data")
    if (!ok && !err) return
    handled.current = true
    const clean = () => window.history.replaceState({}, "", window.location.pathname)
    if (err) {
      toast.error(`Outlook: ${decodeURIComponent(err)}`)
      clean()
      return
    }
    if (ok === "true" && data) {
      try {
        const p = decodePayload(data)
        const c: OutlookConnection = {
          connected: true,
          accessToken: p.accessToken,
          refreshToken: p.refreshToken || undefined,
          expiresAt: p.expiresAt,
          userId: p.userId,
          email: p.email,
          displayName: p.displayName,
          connectedAt: new Date().toISOString(),
        }
        setOutlookConnection(c)
        setView("notetaker")
        toast.success("Outlook calendar connected. Sync to import meetings with Zoom links.")
      } catch {
        toast.error("Could not read Outlook connection data.")
      }
      clean()
    }
  }, [setOutlookConnection, setView])

  return null
}
