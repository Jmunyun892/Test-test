"use client"

import { useEffect, useRef } from "react"
import { toast } from "sonner"
import { useEngagementStore } from "@/lib/engagement-store"

/** Remind once when 4–5 minutes remain before start (Zoom link required). */
const FIVE_MIN_MS = 5 * 60 * 1000
const STORAGE_KEY = "propel-reminded-meetings"

export function MeetingReminder() {
  const meetings = useEngagementStore((s) => s.meetings)
  const reminded = useRef<Set<string>>(new Set())

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY)
      if (raw) {
        const ids = JSON.parse(raw) as string[]
        reminded.current = new Set(ids)
      }
    } catch {
      /* ignore */
    }
  }, [])

  useEffect(() => {
    const tick = () => {
      const now = Date.now()
      for (const m of meetings) {
        if (!m.zoomJoinUrl) continue
        const start = new Date(m.date).getTime()
        const delta = start - now
        if (delta <= 0) continue
        if (delta > FIVE_MIN_MS || delta < FIVE_MIN_MS - 60000) continue
        if (reminded.current.has(m.id)) continue
        reminded.current.add(m.id)
        sessionStorage.setItem(
          STORAGE_KEY,
          JSON.stringify([...reminded.current])
        )
        toast.message("Meeting starting in about 5 minutes", {
          description: m.title,
          action: {
            label: "Join Zoom",
            onClick: () => {
              if (m.zoomJoinUrl) window.location.assign(m.zoomJoinUrl)
            },
          },
          duration: 120000,
        })
      }
    }
    tick()
    const id = window.setInterval(tick, 30000)
    return () => window.clearInterval(id)
  }, [meetings])

  return null
}
