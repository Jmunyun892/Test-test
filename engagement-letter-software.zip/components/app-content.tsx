"use client"

import { AppSidebar } from "@/components/app-sidebar"
import { KPIDashboard } from "@/components/kpi-dashboard"
import { LettersTable } from "@/components/letters-table"
import { LetterEditor } from "@/components/letter-editor"
import { LetterDetail } from "@/components/letter-detail"
import { SalesDashboard } from "@/components/sales-dashboard"
import { WeeklyKPITracker } from "@/components/weekly-kpi-tracker"
import { Notetaker } from "@/components/notetaker"
import { ZoomOAuthHandler } from "@/components/zoom-oauth-handler"
import { OutlookOAuthHandler } from "@/components/outlook-oauth-handler"
import { MeetingReminder } from "@/components/meeting-reminder"
import { useEngagementStore } from "@/lib/engagement-store"
import { Toaster } from "sonner"

export function AppContent() {
  const { view } = useEngagementStore()

  return (
    <>
      <ZoomOAuthHandler />
      <OutlookOAuthHandler />
      <MeetingReminder />
      <div className="flex h-screen bg-background">
        <AppSidebar />
        <main className="flex-1 overflow-hidden">
          {view === "dashboard" && <KPIDashboard />}
          {view === "letters" && <LettersTable />}
          {view === "sales" && <SalesDashboard />}
          {view === "weekly-kpi" && <WeeklyKPITracker />}
          {view === "notetaker" && <Notetaker />}
          {view === "editor" && <LetterEditor />}
          {view === "detail" && <LetterDetail />}
        </main>
      </div>
      <Toaster richColors position="top-center" />
    </>
  )
}
