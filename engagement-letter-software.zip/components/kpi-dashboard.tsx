"use client"

import { useMemo, useState, useEffect } from "react"
import {
  DollarSign,
  TrendingUp,
  Calendar,
  X,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { useEngagementStore } from "@/lib/engagement-store"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
} from "recharts"

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

// KPI Card component
interface KPICardProps {
  title: string
  value: number
  icon: React.ElementType
  subtitle?: string
}

function KPICard({ title, value, icon: Icon, subtitle }: KPICardProps) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          <div className="flex-1">
            <p className="font-heading text-sm text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold text-foreground">{formatCurrency(value)}</p>
            {subtitle && (
              <p className="text-xs text-muted-foreground">{subtitle}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Client breakdown for a month
interface ClientBreakdown {
  clientName: string
  serviceType: string
  mrr: number
  otc: number
  total: number
}

interface MonthData {
  month: string
  monthIndex: number
  mrr: number
  otc: number
  clients: ClientBreakdown[]
}

export function KPIDashboard() {
  const [mounted, setMounted] = useState(false)
  const [selectedMonth, setSelectedMonth] = useState<MonthData | null>(null)
  const { weeklyKPIs, letters } = useEngagementStore()

  useEffect(() => {
    setMounted(true)
  }, [])

  // Calculate YTD and QTD metrics from weekly KPI data
  const metrics = useMemo(() => {
    if (!mounted) return null

    const now = new Date()
    const currentYear = now.getFullYear()
    const currentQuarter = Math.floor(now.getMonth() / 3)
    const quarterStartMonth = currentQuarter * 3

    let ytdMRR = 0
    let qtdMRR = 0
    let ytdOTC = 0
    let qtdOTC = 0

    // Monthly data for chart
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const monthlyData: MonthData[] = months.map((month, index) => ({
      month,
      monthIndex: index,
      mrr: 0,
      otc: 0,
      clients: [],
    }))

    // Aggregate weekly KPI data into months
    weeklyKPIs.forEach((week) => {
      const weekDate = new Date(week.weekStartDate + "T00:00:00")
      const weekYear = weekDate.getFullYear()
      const weekMonth = weekDate.getMonth()

      // YTD calculations (current year)
      if (weekYear === currentYear) {
        ytdMRR += week.mrrClosed
        ytdOTC += week.backworkClosed

        // Add to monthly data
        monthlyData[weekMonth].mrr += week.mrrClosed
        monthlyData[weekMonth].otc += week.backworkClosed
      }

      // QTD calculations (current quarter)
      if (weekYear === currentYear && weekMonth >= quarterStartMonth && weekMonth < quarterStartMonth + 3) {
        qtdMRR += week.mrrClosed
        qtdOTC += week.backworkClosed
      }
    })

    // Get client breakdown from won engagement letters
    const wonLetters = letters.filter((l) => 
      l.status === "won" || l.status === ("signed" as typeof l.status)
    )

    wonLetters.forEach((letter) => {
      if (letter.signedAt) {
        const signedDate = new Date(letter.signedAt)
        const signedYear = signedDate.getFullYear()
        const signedMonth = signedDate.getMonth()

        if (signedYear === currentYear) {
          // Determine if this is MRR or OTC based on service type
          const isMRR = ["Bookkeeping", "Payroll", "Tax"].includes(letter.serviceType)
          
          monthlyData[signedMonth].clients.push({
            clientName: letter.clientName,
            serviceType: letter.serviceType,
            mrr: isMRR ? letter.value : 0,
            otc: isMRR ? 0 : letter.value,
            total: letter.value,
          })
        }
      }
    })

    return {
      ytdMRR,
      qtdMRR,
      ytdOTC,
      qtdOTC,
      chartData: monthlyData,
    }
  }, [mounted, weeklyKPIs, letters])

  const handleBarClick = (data: MonthData) => {
    if (data && (data.mrr > 0 || data.otc > 0 || data.clients.length > 0)) {
      setSelectedMonth(data)
    }
  }

  if (!mounted || !metrics) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-muted-foreground">Loading dashboard...</div>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-heading text-3xl text-foreground">DASHBOARD</h1>
        <p className="text-sm text-muted-foreground">
          Revenue metrics and performance tracking
        </p>
      </div>

      {/* KPI Tiles - 4 in a row */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <KPICard
          title="YTD MRR"
          value={metrics.ytdMRR}
          icon={TrendingUp}
          subtitle="Year to date"
        />
        <KPICard
          title="QTD MRR"
          value={metrics.qtdMRR}
          icon={Calendar}
          subtitle="Quarter to date"
        />
        <KPICard
          title="YTD OTC"
          value={metrics.ytdOTC}
          icon={DollarSign}
          subtitle="Year to date"
        />
        <KPICard
          title="QTD OTC"
          value={metrics.qtdOTC}
          icon={DollarSign}
          subtitle="Quarter to date"
        />
      </div>

      {/* MRR & OTC Monthly Chart */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="font-heading text-xl text-foreground">
            MRR & OTC BY MONTH
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Click on a month to see client breakdown
          </p>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={metrics.chartData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                onClick={(e) => {
                  if (e && e.activePayload && e.activePayload.length > 0) {
                    handleBarClick(e.activePayload[0].payload as MonthData)
                  }
                }}
                style={{ cursor: "pointer" }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="month"
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="rounded-lg border border-border bg-card p-3 shadow-lg">
                          <p className="font-heading text-sm text-foreground">{label}</p>
                          {payload.map((entry, index) => (
                            <p key={index} className="text-sm" style={{ color: entry.color }}>
                              {entry.dataKey === "mrr" ? "MRR" : "OTC"}: {formatCurrency(entry.value as number)}
                            </p>
                          ))}
                          <p className="text-xs text-muted-foreground mt-1">Click for details</p>
                        </div>
                      )
                    }
                    return null
                  }}
                />
                <Legend
                  formatter={(value) => (
                    <span className="text-sm text-foreground">
                      {value === "mrr" ? "MRR" : "OTC"}
                    </span>
                  )}
                />
                <Bar
                  dataKey="mrr"
                  name="mrr"
                  fill="#dcb450"
                  radius={[4, 4, 0, 0]}
                >
                  {metrics.chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-mrr-${index}`} 
                      cursor="pointer"
                      className="hover:opacity-80 transition-opacity"
                    />
                  ))}
                </Bar>
                <Bar
                  dataKey="otc"
                  name="otc"
                  fill="#6366f1"
                  radius={[4, 4, 0, 0]}
                >
                  {metrics.chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-otc-${index}`} 
                      cursor="pointer"
                      className="hover:opacity-80 transition-opacity"
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Month Detail Dialog */}
      <Dialog open={!!selectedMonth} onOpenChange={(open) => !open && setSelectedMonth(null)}>
        <DialogContent className="max-w-2xl bg-card border-border">
          <DialogHeader>
            <DialogTitle className="font-heading text-2xl text-foreground">
              {selectedMonth?.month} BREAKDOWN
            </DialogTitle>
            <DialogDescription>
              Clients won in {selectedMonth?.month} with MRR and OTC breakdown
            </DialogDescription>
          </DialogHeader>

          {/* Summary */}
          <div className="grid grid-cols-3 gap-4 py-4">
            <div className="rounded-lg bg-secondary/50 p-4 text-center">
              <p className="text-sm text-muted-foreground">Total MRR</p>
              <p className="text-2xl font-bold text-primary">
                {formatCurrency(selectedMonth?.mrr || 0)}
              </p>
            </div>
            <div className="rounded-lg bg-secondary/50 p-4 text-center">
              <p className="text-sm text-muted-foreground">Total OTC</p>
              <p className="text-2xl font-bold text-indigo-400">
                {formatCurrency(selectedMonth?.otc || 0)}
              </p>
            </div>
            <div className="rounded-lg bg-secondary/50 p-4 text-center">
              <p className="text-sm text-muted-foreground">Clients Won</p>
              <p className="text-2xl font-bold text-foreground">
                {selectedMonth?.clients.length || 0}
              </p>
            </div>
          </div>

          {/* Client Table */}
          {selectedMonth?.clients && selectedMonth.clients.length > 0 ? (
            <div className="max-h-[300px] overflow-auto rounded-lg border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-secondary/30">
                    <TableHead className="font-heading text-muted-foreground">CLIENT</TableHead>
                    <TableHead className="font-heading text-muted-foreground">SERVICE</TableHead>
                    <TableHead className="font-heading text-muted-foreground text-right">MRR</TableHead>
                    <TableHead className="font-heading text-muted-foreground text-right">OTC</TableHead>
                    <TableHead className="font-heading text-muted-foreground text-right">TOTAL</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedMonth.clients.map((client, index) => (
                    <TableRow key={index} className="hover:bg-secondary/20">
                      <TableCell className="font-medium">{client.clientName}</TableCell>
                      <TableCell className="text-muted-foreground">{client.serviceType}</TableCell>
                      <TableCell className="text-right text-primary">
                        {client.mrr > 0 ? formatCurrency(client.mrr) : "-"}
                      </TableCell>
                      <TableCell className="text-right text-indigo-400">
                        {client.otc > 0 ? formatCurrency(client.otc) : "-"}
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {formatCurrency(client.total)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="rounded-lg border border-border bg-secondary/20 p-8 text-center">
              <p className="text-muted-foreground">No clients won in this month yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Revenue shown is from weekly KPI entries
              </p>
            </div>
          )}

          <div className="flex justify-end pt-4">
            <Button variant="outline" onClick={() => setSelectedMonth(null)}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
