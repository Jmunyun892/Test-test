// Zoom OAuth Configuration
export const ZOOM_CONFIG = {
  clientId: process.env.NEXT_PUBLIC_ZOOM_CLIENT_ID || "",
  clientSecret: process.env.ZOOM_CLIENT_SECRET || "",
  redirectUri: process.env.NEXT_PUBLIC_ZOOM_REDIRECT_URI || "http://localhost:3000/api/zoom/callback",
  authUrl: "https://zoom.us/oauth/authorize",
  tokenUrl: "https://zoom.us/oauth/token",
  apiUrl: "https://api.zoom.us/v2",
  /** Space-separated; must match scopes enabled on your Zoom OAuth app */
  scopes:
    process.env.ZOOM_OAUTH_SCOPES ||
    "user:read:user cloud_recording:read:list_user_recordings",
}

export class ZoomApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.name = "ZoomApiError"
    this.status = status
  }
}

// Generate OAuth authorization URL
export function getZoomAuthUrl(state?: string): string {
  const params = new URLSearchParams({
    response_type: "code",
    client_id: ZOOM_CONFIG.clientId,
    redirect_uri: ZOOM_CONFIG.redirectUri,
    state: state || crypto.randomUUID(),
    scope: ZOOM_CONFIG.scopes,
  })

  return `${ZOOM_CONFIG.authUrl}?${params.toString()}`
}

// Exchange authorization code for tokens
export async function exchangeCodeForTokens(code: string): Promise<{
  access_token: string
  refresh_token: string
  expires_in: number
  token_type: string
  scope: string
}> {
  const credentials = Buffer.from(
    `${ZOOM_CONFIG.clientId}:${ZOOM_CONFIG.clientSecret}`
  ).toString("base64")

  const response = await fetch(ZOOM_CONFIG.tokenUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${credentials}`,
    },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: ZOOM_CONFIG.redirectUri,
    }),
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`Failed to exchange code: ${error}`)
  }

  return response.json()
}

// Refresh access token
export async function refreshAccessToken(refreshToken: string): Promise<{
  access_token: string
  refresh_token: string
  expires_in: number
  token_type: string
  scope: string
}> {
  const credentials = Buffer.from(
    `${ZOOM_CONFIG.clientId}:${ZOOM_CONFIG.clientSecret}`
  ).toString("base64")

  const response = await fetch(ZOOM_CONFIG.tokenUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${credentials}`,
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
    }),
  })

  if (!response.ok) {
    const error = await response.text()
    throw new Error(`Failed to refresh token: ${error}`)
  }

  return response.json()
}

// Get user info
export async function getZoomUser(accessToken: string): Promise<{
  id: string
  email: string
  first_name: string
  last_name: string
  display_name: string
  account_id: string
  pic_url: string
}> {
  const response = await fetch(`${ZOOM_CONFIG.apiUrl}/users/me`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  })

  if (!response.ok) {
    const error = await response.text()
    throw new ZoomApiError(`Failed to get user: ${error}`, response.status)
  }

  return response.json()
}

export type ZoomRecordingFile = {
  id: string
  meeting_id: string
  recording_start: string
  recording_end: string
  file_type: string
  file_size: number
  play_url?: string
  download_url?: string
  status: string
}

export type ZoomRecordingMeeting = {
  uuid: string
  id: number
  host_id: string
  topic: string
  start_time: string
  duration: number
  total_size?: number
  recording_count?: number
  share_url?: string
  recording_files?: ZoomRecordingFile[]
}

export type ZoomRecordingsPage = {
  meetings: ZoomRecordingMeeting[]
  next_page_token?: string
}

// One page of cloud recordings for the authenticated user
export async function getZoomRecordingsPage(
  accessToken: string,
  options: {
    from?: string
    to?: string
    pageSize?: number
    nextPageToken?: string
  } = {}
): Promise<ZoomRecordingsPage> {
  const params = new URLSearchParams()
  if (options.from) params.set("from", options.from)
  if (options.to) params.set("to", options.to)
  params.set("page_size", String(options.pageSize ?? 30))
  if (options.nextPageToken) params.set("next_page_token", options.nextPageToken)

  const response = await fetch(
    `${ZOOM_CONFIG.apiUrl}/users/me/recordings?${params.toString()}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  )

  if (!response.ok) {
    const error = await response.text()
    throw new ZoomApiError(`Failed to get recordings: ${error}`, response.status)
  }

  return response.json()
}

/** Fetch all pages of recordings in the date range (inclusive). */
export async function fetchAllZoomRecordings(
  accessToken: string,
  from: string,
  to: string
): Promise<ZoomRecordingMeeting[]> {
  const all: ZoomRecordingMeeting[] = []
  let next: string | undefined

  do {
    const page = await getZoomRecordingsPage(accessToken, {
      from,
      to,
      nextPageToken: next,
    })
    all.push(...(page.meetings ?? []))
    next = page.next_page_token
  } while (next)

  return all
}

/** Download a cloud recording file (VTT, etc.); Zoom requires access_token on the URL. */
export async function downloadZoomCloudFile(
  accessToken: string,
  downloadUrl: string
): Promise<string> {
  const sep = downloadUrl.includes("?") ? "&" : "?"
  const url = `${downloadUrl}${sep}access_token=${encodeURIComponent(accessToken)}`
  const response = await fetch(url)
  if (!response.ok) {
    const err = await response.text()
    throw new ZoomApiError(`Failed to download recording file: ${err}`, response.status)
  }
  return response.text()
}

// Get meeting details
export async function getZoomMeeting(
  accessToken: string,
  meetingId: string
): Promise<{
  uuid: string
  id: number
  topic: string
  start_time: string
  duration: number
  timezone: string
  agenda: string
  host_email: string
}> {
  const response = await fetch(
    `${ZOOM_CONFIG.apiUrl}/meetings/${meetingId}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  )

  if (!response.ok) {
    const error = await response.text()
    throw new ZoomApiError(`Failed to get meeting: ${error}`, response.status)
  }

  return response.json()
}

/** @deprecated Prefer getZoomRecordingsPage or fetchAllZoomRecordings */
export async function getZoomRecordings(
  accessToken: string,
  from?: string,
  to?: string
): Promise<{ meetings: ZoomRecordingMeeting[] }> {
  const meetings = await fetchAllZoomRecordings(
    accessToken,
    from ?? new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    to ?? new Date().toISOString().split("T")[0]
  )
  return { meetings }
}
