import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  scryptSync,
} from "crypto"

const SALT = Buffer.from("zoom-rec-stream-v1", "utf8")

function deriveKey(): Buffer {
  const secret =
    process.env.ZOOM_STREAM_SECRET ||
    process.env.ZOOM_CLIENT_SECRET ||
    "dev-only-change-ZOOM_STREAM_SECRET"
  return scryptSync(secret, SALT, 32)
}

export type StreamContextPayload = {
  u: string
  t: string
  exp: number
}

/** Encrypted blob for cookie or query (same-origin video proxy). */
export function sealStreamContext(
  recordingUrl: string,
  zoomAccessToken: string,
  ttlSec = 7200
): string {
  const payload: StreamContextPayload = {
    u: recordingUrl,
    t: zoomAccessToken,
    exp: Math.floor(Date.now() / 1000) + ttlSec,
  }
  const json = JSON.stringify(payload)
  const iv = randomBytes(12)
  const cipher = createCipheriv("aes-256-gcm", deriveKey(), iv)
  const enc = Buffer.concat([cipher.update(json, "utf8"), cipher.final()])
  const tag = cipher.getAuthTag()
  return Buffer.concat([iv, enc, tag]).toString("base64url")
}

export function unsealStreamContext(blob: string): StreamContextPayload | null {
  try {
    const raw = Buffer.from(blob, "base64url")
    if (raw.length < 29) return null
    const iv = raw.subarray(0, 12)
    const tag = raw.subarray(raw.length - 16)
    const enc = raw.subarray(12, raw.length - 16)
    const decipher = createDecipheriv("aes-256-gcm", deriveKey(), iv)
    decipher.setAuthTag(tag)
    const json = Buffer.concat([decipher.update(enc), decipher.final()]).toString(
      "utf8"
    )
    const o = JSON.parse(json) as StreamContextPayload
    if (!o.u || typeof o.exp !== "number") return null
    if (o.exp < Date.now() / 1000) return null
    return o
  } catch {
    return null
  }
}
