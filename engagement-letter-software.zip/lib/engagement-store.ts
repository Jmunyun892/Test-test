"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { EngagementLetter, LetterStatus, KPIData, SalesRecord, SaleStage, SalesKPIData, WeeklyKPIEntry, WeeklyKPIGoals, Meeting, ZoomConnection, OutlookConnection } from "./types"

// Sample data for demonstration
const sampleLetters: EngagementLetter[] = [
  {
    id: "1",
    title: "Annual Audit Services Agreement",
    clientName: "Acme Corporation",
    clientEmail: "finance@acme.com",
    serviceType: "Audit",
    content: `<h2>Engagement Letter</h2>
<p>Dear Acme Corporation,</p>
<p>We are pleased to confirm our understanding of the services we are to provide for Acme Corporation for the fiscal year ending December 31, 2026.</p>
<h3>Scope of Services</h3>
<p>We will audit the financial statements of Acme Corporation, which comprise the balance sheet as of December 31, 2026, and the related statements of income, changes in stockholders' equity, and cash flows for the year then ended.</p>
<h3>Fees</h3>
<p>Our fees for this engagement will be $45,000.</p>`,
    status: "won",
    createdAt: new Date("2026-01-15"),
    updatedAt: new Date("2026-01-20"),
    sentAt: new Date("2026-01-16"),
    signedAt: new Date("2026-01-20"),
    value: 45000,
  },
  {
    id: "2",
    title: "Tax Planning Services",
    clientName: "TechStart Inc",
    clientEmail: "cfo@techstart.io",
    serviceType: "Tax",
    content: `<h2>Tax Planning Engagement</h2>
<p>Dear TechStart Inc,</p>
<p>This letter confirms our engagement to provide tax planning services for the 2026 tax year.</p>
<h3>Services Include</h3>
<ul>
<li>Tax planning strategies</li>
<li>Quarterly tax estimates</li>
<li>Year-end tax review</li>
</ul>
<h3>Fees</h3>
<p>Our estimated fee for these services is $12,500.</p>`,
    status: "viewed",
    createdAt: new Date("2026-02-01"),
    updatedAt: new Date("2026-02-05"),
    sentAt: new Date("2026-02-05"),
    value: 12500,
  },
  {
    id: "3",
    title: "Bookkeeping Services Agreement",
    clientName: "Green Gardens LLC",
    clientEmail: "owner@greengardens.com",
    serviceType: "Bookkeeping",
    content: `<h2>Monthly Bookkeeping Services</h2>
<p>Dear Green Gardens LLC,</p>
<p>We are pleased to offer our monthly bookkeeping services.</p>
<h3>Services</h3>
<ul>
<li>Monthly reconciliation</li>
<li>Financial statement preparation</li>
<li>Accounts payable/receivable management</li>
</ul>`,
    status: "draft",
    createdAt: new Date("2026-02-28"),
    updatedAt: new Date("2026-03-01"),
    value: 24000,
  },
  {
    id: "4",
    title: "Financial Advisory Services",
    clientName: "Bright Future Foundation",
    clientEmail: "admin@brightfuture.org",
    serviceType: "Advisory",
    content: `<h2>Advisory Services Agreement</h2>
<p>This engagement letter outlines our advisory services for Bright Future Foundation.</p>`,
    status: "won",
    createdAt: new Date("2026-01-05"),
    updatedAt: new Date("2026-01-12"),
    sentAt: new Date("2026-01-06"),
    signedAt: new Date("2026-01-12"),
    value: 35000,
  },
  {
    id: "5",
    title: "Quarterly Review Services",
    clientName: "Metro Retail Group",
    clientEmail: "accounting@metroretail.com",
    serviceType: "Review",
    content: `<h2>Quarterly Review Engagement</h2>
<p>We will perform quarterly reviews of your financial statements.</p>`,
    status: "expired",
    createdAt: new Date("2025-12-01"),
    updatedAt: new Date("2025-12-15"),
    sentAt: new Date("2025-12-02"),
    expiresAt: new Date("2025-12-31"),
    value: 18000,
  },
  {
    id: "6",
    title: "M&A Due Diligence",
    clientName: "Growth Capital Partners",
    clientEmail: "deals@growthcp.com",
    serviceType: "Advisory",
    content: `<h2>Due Diligence Services</h2>
<p>We will perform financial due diligence for your proposed acquisition.</p>`,
    status: "sent",
    createdAt: new Date("2026-03-10"),
    updatedAt: new Date("2026-03-12"),
    sentAt: new Date("2026-03-12"),
    value: 75000,
  },
  {
    id: "7",
    title: "Payroll Services Setup",
    clientName: "Sunrise Cafe",
    clientEmail: "manager@sunrisecafe.com",
    serviceType: "Payroll",
    content: `<h2>Payroll Services</h2>
<p>This letter outlines our payroll processing services.</p>`,
    status: "rejected",
    createdAt: new Date("2026-02-20"),
    updatedAt: new Date("2026-02-25"),
    sentAt: new Date("2026-02-21"),
    value: 6000,
  },
]

// Sample sales data
const sampleSalesRecords: SalesRecord[] = [
  {
    id: "s1",
    clientName: "Acme Corporation",
    contactEmail: "finance@acme.com",
    serviceType: "Audit",
    estimatedValue: 50000,
    actualValue: 45000,
    stage: "closed_won",
    probability: 100,
    source: "Referral",
    assignedTo: "John Doe",
    createdAt: new Date("2025-11-15"),
    updatedAt: new Date("2026-01-20"),
    expectedCloseDate: new Date("2026-01-31"),
    closedAt: new Date("2026-01-20"),
    notes: "Long-term client, annual audit renewal",
    linkedLetterId: "1",
  },
  {
    id: "s2",
    clientName: "TechStart Inc",
    contactEmail: "cfo@techstart.io",
    serviceType: "Tax",
    estimatedValue: 15000,
    stage: "proposal",
    probability: 60,
    source: "Website",
    assignedTo: "Jane Smith",
    createdAt: new Date("2026-01-20"),
    updatedAt: new Date("2026-02-05"),
    expectedCloseDate: new Date("2026-03-15"),
    notes: "Growing tech startup, needs comprehensive tax planning",
    linkedLetterId: "2",
  },
  {
    id: "s3",
    clientName: "Green Gardens LLC",
    contactEmail: "owner@greengardens.com",
    serviceType: "Bookkeeping",
    estimatedValue: 24000,
    stage: "qualified",
    probability: 40,
    source: "Cold Outreach",
    assignedTo: "John Doe",
    createdAt: new Date("2026-02-15"),
    updatedAt: new Date("2026-03-01"),
    expectedCloseDate: new Date("2026-04-01"),
    notes: "Local business expanding, needs monthly support",
    linkedLetterId: "3",
  },
  {
    id: "s4",
    clientName: "Bright Future Foundation",
    contactEmail: "admin@brightfuture.org",
    serviceType: "Advisory",
    estimatedValue: 40000,
    actualValue: 35000,
    stage: "closed_won",
    probability: 100,
    source: "Networking Event",
    assignedTo: "Jane Smith",
    createdAt: new Date("2025-12-01"),
    updatedAt: new Date("2026-01-12"),
    expectedCloseDate: new Date("2026-01-31"),
    closedAt: new Date("2026-01-12"),
    notes: "Non-profit needs financial advisory for grant management",
    linkedLetterId: "4",
  },
  {
    id: "s5",
    clientName: "Metro Retail Group",
    contactEmail: "accounting@metroretail.com",
    serviceType: "Review",
    estimatedValue: 18000,
    stage: "closed_lost",
    probability: 0,
    source: "Referral",
    assignedTo: "Mike Johnson",
    createdAt: new Date("2025-10-15"),
    updatedAt: new Date("2025-12-15"),
    expectedCloseDate: new Date("2025-12-31"),
    closedAt: new Date("2025-12-15"),
    notes: "Lost to competitor on price",
    linkedLetterId: "5",
  },
  {
    id: "s6",
    clientName: "Growth Capital Partners",
    contactEmail: "deals@growthcp.com",
    serviceType: "Advisory",
    estimatedValue: 85000,
    stage: "negotiation",
    probability: 75,
    source: "LinkedIn",
    assignedTo: "John Doe",
    createdAt: new Date("2026-02-20"),
    updatedAt: new Date("2026-03-12"),
    expectedCloseDate: new Date("2026-04-15"),
    notes: "Large PE firm, high-value M&A work",
    linkedLetterId: "6",
  },
  {
    id: "s7",
    clientName: "Sunrise Cafe",
    contactEmail: "manager@sunrisecafe.com",
    serviceType: "Payroll",
    estimatedValue: 8000,
    stage: "closed_lost",
    probability: 0,
    source: "Website",
    assignedTo: "Jane Smith",
    createdAt: new Date("2026-01-10"),
    updatedAt: new Date("2026-02-25"),
    expectedCloseDate: new Date("2026-02-28"),
    closedAt: new Date("2026-02-25"),
    notes: "Small business, decided to use DIY software",
    linkedLetterId: "7",
  },
  {
    id: "s8",
    clientName: "Innovative Labs",
    contactEmail: "cfo@innovativelabs.tech",
    serviceType: "Audit",
    estimatedValue: 65000,
    stage: "lead",
    probability: 20,
    source: "Conference",
    assignedTo: "Mike Johnson",
    createdAt: new Date("2026-03-01"),
    updatedAt: new Date("2026-03-10"),
    expectedCloseDate: new Date("2026-06-01"),
    notes: "Initial contact at tech conference, Series B funded",
  },
  {
    id: "s9",
    clientName: "Heritage Hotels Group",
    contactEmail: "finance@heritagehotels.com",
    serviceType: "Tax",
    estimatedValue: 55000,
    stage: "proposal",
    probability: 50,
    source: "Referral",
    assignedTo: "John Doe",
    createdAt: new Date("2026-02-10"),
    updatedAt: new Date("2026-03-05"),
    expectedCloseDate: new Date("2026-04-30"),
    notes: "Hotel chain with multiple properties, complex tax situation",
  },
  {
    id: "s10",
    clientName: "ClearWater Manufacturing",
    contactEmail: "controller@clearwater.com",
    serviceType: "Audit",
    estimatedValue: 72000,
    actualValue: 72000,
    stage: "closed_won",
    probability: 100,
    source: "Cold Outreach",
    assignedTo: "Jane Smith",
    createdAt: new Date("2025-09-01"),
    updatedAt: new Date("2025-11-15"),
    expectedCloseDate: new Date("2025-12-01"),
    closedAt: new Date("2025-11-15"),
    notes: "Manufacturing company, 3-year engagement",
  },
]

// Sample weekly KPI data
const sampleWeeklyKPIs: WeeklyKPIEntry[] = [
  {
    id: "w1",
    weekStartDate: "2026-03-02",
    weekEndDate: "2026-03-08",
    discoveryCalls: 8,
    unqualifiedDeals: 2,
    pricingCalls: 4,
    mrrProposed: 12500,
    backworkProposed: 8000,
    backworkClosed: 5500,
    mrrClosed: 4200,
    numberOfClients: 3,
    networkingEvents: 1,
    clientCheckInCalls: 6,
    notes: "Strong week for discovery calls",
    createdAt: new Date("2026-03-08"),
    updatedAt: new Date("2026-03-08"),
  },
  {
    id: "w2",
    weekStartDate: "2026-03-09",
    weekEndDate: "2026-03-15",
    discoveryCalls: 6,
    unqualifiedDeals: 1,
    pricingCalls: 5,
    mrrProposed: 15000,
    backworkProposed: 12000,
    backworkClosed: 7000,
    mrrClosed: 6500,
    numberOfClients: 2,
    networkingEvents: 2,
    clientCheckInCalls: 8,
    notes: "Good networking week",
    createdAt: new Date("2026-03-15"),
    updatedAt: new Date("2026-03-15"),
  },
  {
    id: "w3",
    weekStartDate: "2026-03-16",
    weekEndDate: "2026-03-22",
    discoveryCalls: 10,
    unqualifiedDeals: 3,
    pricingCalls: 6,
    mrrProposed: 18000,
    backworkProposed: 15000,
    backworkClosed: 9500,
    mrrClosed: 8200,
    numberOfClients: 4,
    networkingEvents: 1,
    clientCheckInCalls: 5,
    notes: "Best week for client acquisition",
    createdAt: new Date("2026-03-22"),
    updatedAt: new Date("2026-03-22"),
  },
  {
    id: "w4",
    weekStartDate: "2026-03-23",
    weekEndDate: "2026-03-29",
    discoveryCalls: 5,
    unqualifiedDeals: 1,
    pricingCalls: 3,
    mrrProposed: 9000,
    backworkProposed: 6000,
    backworkClosed: 4000,
    mrrClosed: 3500,
    numberOfClients: 1,
    networkingEvents: 0,
    clientCheckInCalls: 7,
    notes: "Current week in progress",
    createdAt: new Date("2026-03-27"),
    updatedAt: new Date("2026-03-27"),
  },
]

const defaultWeeklyGoals: WeeklyKPIGoals = {
  discoveryCalls: 8,
  unqualifiedDeals: 2,
  pricingCalls: 5,
  mrrProposed: 15000,
  backworkProposed: 10000,
  backworkClosed: 7500,
  mrrClosed: 6000,
  numberOfClients: 3,
  networkingEvents: 2,
  clientCheckInCalls: 6,
}

// Sample meetings data
const sampleMeetings: Meeting[] = [
  {
    id: "m1",
    title: "Discovery Call - Acme Corporation",
    date: new Date("2026-03-25T10:00:00"),
    duration: 45,
    participants: ["John Doe", "Sarah Johnson (Acme CFO)", "Mike Chen (Acme Controller)"],
    platform: "zoom",
    recordingUrl: "https://example.com/recording1",
    thumbnailUrl: "/placeholder-meeting.jpg",
    transcript: [
      { timestamp: "00:00", speaker: "John Doe", text: "Thanks for joining today. I wanted to discuss your accounting needs for the upcoming year." },
      { timestamp: "00:15", speaker: "Sarah Johnson", text: "Absolutely, we've been looking to streamline our financial processes." },
      { timestamp: "00:32", speaker: "John Doe", text: "Great. Can you tell me about your current setup and pain points?" },
      { timestamp: "00:45", speaker: "Mike Chen", text: "We're currently using QuickBooks but it's not scaling well with our growth." },
      { timestamp: "01:10", speaker: "Sarah Johnson", text: "Yes, and our audit process last year was quite painful. We need better documentation." },
      { timestamp: "01:35", speaker: "John Doe", text: "I understand. Our firm specializes in helping growing companies like yours transition to more robust systems." },
      { timestamp: "02:00", speaker: "John Doe", text: "We typically start with a comprehensive assessment of your current processes." },
      { timestamp: "02:20", speaker: "Mike Chen", text: "That sounds helpful. What does that assessment involve?" },
      { timestamp: "02:45", speaker: "John Doe", text: "We'll review your chart of accounts, monthly close process, and reporting needs." },
    ],
    summary: "Discovery call with Acme Corporation to discuss their accounting needs. They are experiencing growing pains with QuickBooks and had difficulties during their last audit. They are interested in a comprehensive assessment of their financial processes and potentially transitioning to a more robust system. Key stakeholders are Sarah Johnson (CFO) and Mike Chen (Controller).",
    keyPoints: [
      "Current QuickBooks setup not scaling with company growth",
      "Last audit was challenging due to documentation issues",
      "Interested in comprehensive financial process assessment",
      "Need better monthly close procedures",
      "Looking to improve reporting capabilities"
    ],
    actionItems: [
      "Send proposal for financial assessment - Due: March 28",
      "Schedule follow-up call with IT team - Due: April 1",
      "Prepare case study from similar client - Due: March 27"
    ],
    clientName: "Acme Corporation",
    tags: ["discovery", "audit", "growth"],
    createdAt: new Date("2026-03-25"),
    updatedAt: new Date("2026-03-25"),
  },
  {
    id: "m2",
    title: "Pricing Call - TechStart Inc",
    date: new Date("2026-03-22T14:00:00"),
    duration: 30,
    participants: ["John Doe", "Alex Rivera (TechStart CEO)"],
    platform: "zoom",
    recordingUrl: "https://example.com/recording2",
    thumbnailUrl: "/placeholder-meeting.jpg",
    transcript: [
      { timestamp: "00:00", speaker: "John Doe", text: "Hi Alex, thanks for taking the time to discuss pricing for our tax planning services." },
      { timestamp: "00:12", speaker: "Alex Rivera", text: "Of course, we reviewed your proposal and have a few questions." },
      { timestamp: "00:25", speaker: "Alex Rivera", text: "The monthly retainer seems reasonable, but can you break down the quarterly review fees?" },
      { timestamp: "00:45", speaker: "John Doe", text: "Absolutely. The quarterly reviews include a detailed analysis of your tax position and strategic recommendations." },
      { timestamp: "01:10", speaker: "John Doe", text: "This helps us identify savings opportunities before year-end." },
      { timestamp: "01:30", speaker: "Alex Rivera", text: "That makes sense. What about the R&D tax credit study?" },
      { timestamp: "01:50", speaker: "John Doe", text: "Great question. Given your software development activities, you likely qualify for significant credits." },
    ],
    summary: "Pricing discussion with TechStart Inc for tax planning services. Alex Rivera reviewed the proposal and had questions about quarterly review fees and R&D tax credit study. Client seems interested in moving forward with the engagement.",
    keyPoints: [
      "Monthly retainer acceptable to client",
      "Need detailed breakdown of quarterly review scope",
      "Strong interest in R&D tax credit study",
      "Software development activities qualify for credits"
    ],
    actionItems: [
      "Send revised proposal with detailed scope - Due: March 24",
      "Include R&D credit estimate in proposal",
      "Prepare engagement letter for signature"
    ],
    clientName: "TechStart Inc",
    tags: ["pricing", "tax", "r&d-credit"],
    createdAt: new Date("2026-03-22"),
    updatedAt: new Date("2026-03-22"),
  },
  {
    id: "m3",
    title: "Client Check-in - Green Gardens LLC",
    date: new Date("2026-03-20T11:00:00"),
    duration: 25,
    participants: ["Jane Smith", "Tom Wilson (Green Gardens Owner)"],
    platform: "zoom",
    recordingUrl: "https://example.com/recording3",
    thumbnailUrl: "/placeholder-meeting.jpg",
    transcript: [
      { timestamp: "00:00", speaker: "Jane Smith", text: "Hi Tom, how are things going with the new bookkeeping system?" },
      { timestamp: "00:10", speaker: "Tom Wilson", text: "Great actually! The monthly reports have been super helpful." },
      { timestamp: "00:25", speaker: "Jane Smith", text: "Wonderful to hear. Any questions about the Q1 financials?" },
      { timestamp: "00:40", speaker: "Tom Wilson", text: "Yes, I noticed our labor costs are up 15%. Is that concerning?" },
      { timestamp: "01:00", speaker: "Jane Smith", text: "Good catch. That's primarily due to the new hires in January. Let me show you the breakdown." },
    ],
    summary: "Quarterly check-in with Green Gardens LLC. Client is happy with the new bookkeeping system and monthly reports. Discussed Q1 financials and addressed concerns about increased labor costs due to January hiring.",
    keyPoints: [
      "Client satisfied with new bookkeeping system",
      "Monthly reports proving valuable",
      "Labor costs up 15% due to new hires",
      "Q1 financials reviewed"
    ],
    actionItems: [
      "Send detailed labor cost analysis",
      "Schedule Q2 planning meeting"
    ],
    clientName: "Green Gardens LLC",
    tags: ["check-in", "bookkeeping", "quarterly"],
    createdAt: new Date("2026-03-20"),
    updatedAt: new Date("2026-03-20"),
  },
  {
    id: "m4",
    title: "Advisory Session - Bright Future Foundation",
    date: new Date("2026-03-18T09:00:00"),
    duration: 60,
    participants: ["John Doe", "Maria Santos (Executive Director)", "Kevin Park (Board Treasurer)"],
    platform: "google_meet",
    recordingUrl: "https://example.com/recording4",
    thumbnailUrl: "/placeholder-meeting.jpg",
    transcript: [
      { timestamp: "00:00", speaker: "John Doe", text: "Good morning. Today we'll review the grant management procedures and financial controls." },
      { timestamp: "00:20", speaker: "Maria Santos", text: "Perfect. We have three new grants starting next quarter and want to ensure compliance." },
      { timestamp: "00:45", speaker: "Kevin Park", text: "The board has also asked about improving our financial reporting to donors." },
      { timestamp: "01:10", speaker: "John Doe", text: "Both great priorities. Let's start with the grant tracking system I mentioned last month." },
    ],
    summary: "Advisory session with Bright Future Foundation focused on grant management procedures and financial controls. Three new grants starting next quarter requiring compliance setup. Board interested in improved donor financial reporting.",
    keyPoints: [
      "Three new grants starting Q2",
      "Need compliance procedures for new grants",
      "Board wants better donor reporting",
      "Implementing new grant tracking system"
    ],
    actionItems: [
      "Set up grant tracking templates - Due: March 25",
      "Create donor reporting dashboard",
      "Schedule board presentation on new procedures"
    ],
    clientName: "Bright Future Foundation",
    tags: ["advisory", "nonprofit", "grants"],
    createdAt: new Date("2026-03-18"),
    updatedAt: new Date("2026-03-18"),
  },
]

interface EngagementStore {
  letters: EngagementLetter[]
  salesRecords: SalesRecord[]
  weeklyKPIs: WeeklyKPIEntry[]
  weeklyGoals: WeeklyKPIGoals
  meetings: Meeting[]
  zoomConnection: ZoomConnection
  outlookConnection: OutlookConnection
  selectedLetterId: string | null
  selectedSaleId: string | null
  selectedMeetingId: string | null
  view: "dashboard" | "letters" | "editor" | "detail" | "sales" | "weekly-kpi" | "notetaker"
  addLetter: (letter: Omit<EngagementLetter, "id" | "createdAt" | "updatedAt">) => void
  updateLetter: (id: string, updates: Partial<EngagementLetter>) => void
  deleteLetter: (id: string) => void
  setSelectedLetter: (id: string | null) => void
  setView: (view: "dashboard" | "letters" | "editor" | "detail" | "sales" | "weekly-kpi" | "notetaker") => void
  getKPIData: () => KPIData
  // Sales functions
  addSalesRecord: (record: Omit<SalesRecord, "id" | "createdAt" | "updatedAt">) => void
  updateSalesRecord: (id: string, updates: Partial<SalesRecord>) => void
  deleteSalesRecord: (id: string) => void
  setSelectedSale: (id: string | null) => void
  getSalesKPIData: () => SalesKPIData
  // Weekly KPI functions
  addWeeklyKPI: (entry: Omit<WeeklyKPIEntry, "id" | "createdAt" | "updatedAt">) => void
  updateWeeklyKPI: (id: string, updates: Partial<WeeklyKPIEntry>) => void
  deleteWeeklyKPI: (id: string) => void
  updateWeeklyGoals: (goals: WeeklyKPIGoals) => void
  getWeeklyKPIById: (id: string) => WeeklyKPIEntry | undefined
  getCurrentWeekKPI: () => WeeklyKPIEntry | undefined
  // Meeting functions
  addMeeting: (meeting: Omit<Meeting, "id" | "createdAt" | "updatedAt">) => void
  updateMeeting: (id: string, updates: Partial<Meeting>) => void
  deleteMeeting: (id: string) => void
  setSelectedMeeting: (id: string | null) => void
  getMeetingById: (id: string) => Meeting | undefined
  setZoomConnection: (connection: ZoomConnection) => void
  clearZoomConnection: () => void
  upsertZoomMeetings: (meetings: Meeting[]) => void
  setOutlookConnection: (connection: OutlookConnection) => void
  clearOutlookConnection: () => void
  upsertOutlookMeetings: (meetings: Meeting[]) => void
}

export const useEngagementStore = create<EngagementStore>()(
  persist(
    (set, get) => ({
      letters: sampleLetters,
      salesRecords: sampleSalesRecords,
      weeklyKPIs: sampleWeeklyKPIs,
      weeklyGoals: defaultWeeklyGoals,
      meetings: sampleMeetings,
      zoomConnection: { connected: false },
      outlookConnection: { connected: false },
      selectedLetterId: null,
      selectedSaleId: null,
      selectedMeetingId: null,
      view: "dashboard",

      addLetter: (letterData) => {
        const newLetter: EngagementLetter = {
          ...letterData,
          id: crypto.randomUUID(),
          createdAt: new Date(),
          updatedAt: new Date(),
        }
        set((state) => ({ letters: [...state.letters, newLetter] }))
      },

      updateLetter: (id, updates) => {
        set((state) => ({
          letters: state.letters.map((letter) =>
            letter.id === id
              ? { ...letter, ...updates, updatedAt: new Date() }
              : letter
          ),
        }))
      },

      deleteLetter: (id) => {
        set((state) => ({
          letters: state.letters.filter((letter) => letter.id !== id),
          selectedLetterId:
            state.selectedLetterId === id ? null : state.selectedLetterId,
        }))
      },

      setSelectedLetter: (id) => set({ selectedLetterId: id }),

      setView: (view) => set({ view }),

      // Sales functions
      addSalesRecord: (recordData) => {
        const newRecord: SalesRecord = {
          ...recordData,
          id: crypto.randomUUID(),
          createdAt: new Date(),
          updatedAt: new Date(),
        }
        set((state) => ({ salesRecords: [...state.salesRecords, newRecord] }))
      },

      updateSalesRecord: (id, updates) => {
        set((state) => ({
          salesRecords: state.salesRecords.map((record) =>
            record.id === id
              ? { ...record, ...updates, updatedAt: new Date() }
              : record
          ),
        }))
      },

      deleteSalesRecord: (id) => {
        set((state) => ({
          salesRecords: state.salesRecords.filter((record) => record.id !== id),
          selectedSaleId:
            state.selectedSaleId === id ? null : state.selectedSaleId,
        }))
      },

      setSelectedSale: (id) => set({ selectedSaleId: id }),

      getKPIData: () => {
        const letters = get().letters
        const wonLetters = letters.filter((l) => l.status === "won")
        const pendingLetters = letters.filter(
          (l) => l.status === "sent" || l.status === "draft" || l.status === "viewed"
        )
        const totalValue = letters.reduce((sum, l) => sum + l.value, 0)
        const wonValue = wonLetters.reduce((sum, l) => sum + l.value, 0)

        // Calculate average time to win (in days)
        const wonWithTime = wonLetters.filter((l) => l.sentAt && l.signedAt)
        const avgTimeToSign =
          wonWithTime.length > 0
            ? wonWithTime.reduce((sum, l) => {
                const sent = new Date(l.sentAt!).getTime()
                const signed = new Date(l.signedAt!).getTime()
                return sum + (signed - sent) / (1000 * 60 * 60 * 24)
              }, 0) / wonWithTime.length
            : 0

        // Status breakdown
        const statusCounts: Record<LetterStatus, number> = {
          draft: 0,
          sent: 0,
          viewed: 0,
          won: 0,
          expired: 0,
          rejected: 0,
        }
        letters.forEach((l) => {
          statusCounts[l.status]++
        })

        const lettersByStatus = [
          { status: "Draft", count: statusCounts.draft, fill: "var(--chart-3)" },
          { status: "Sent", count: statusCounts.sent, fill: "var(--chart-1)" },
          { status: "Viewed", count: statusCounts.viewed, fill: "var(--primary)" },
          { status: "Won", count: statusCounts.won, fill: "var(--chart-2)" },
          { status: "Expired", count: statusCounts.expired, fill: "var(--chart-4)" },
          { status: "Rejected", count: statusCounts.rejected, fill: "var(--chart-5)" },
        ]

        // Monthly data (last 6 months) - static data to avoid hydration mismatch
        const lettersByMonth = [
          { month: "Oct", sent: 5, signed: 3 },
          { month: "Nov", sent: 8, signed: 5 },
          { month: "Dec", sent: 6, signed: 4 },
          { month: "Jan", sent: 9, signed: 6 },
          { month: "Feb", sent: 7, signed: 5 },
          { month: "Mar", sent: 10, signed: 7 },
        ]

        // Recent activity - use ISO date string for consistent server/client rendering
        const formatDateConsistent = (date: Date) => {
          const d = new Date(date)
          const year = d.getUTCFullYear()
          const month = String(d.getUTCMonth() + 1).padStart(2, "0")
          const day = String(d.getUTCDate()).padStart(2, "0")
          return `${year}-${month}-${day}`
        }

        const recentActivity = letters
          .slice(0, 5)
          .map((l) => ({
            date: formatDateConsistent(l.updatedAt),
            action:
              l.status === "won"
                ? "Won"
                : l.status === "viewed"
                ? "Viewed"
                : l.status === "sent"
                ? "Sent"
                : l.status === "draft"
                ? "Created"
                : l.status === "expired"
                ? "Expired"
                : "Rejected",
            letter: l.title,
          }))

        return {
          totalLetters: letters.length,
          signedLetters: wonLetters.length,
          pendingLetters: pendingLetters.length,
          totalValue,
          signedValue: wonValue,
          conversionRate:
            letters.length > 0
              ? (wonLetters.length / letters.length) * 100
              : 0,
          averageTimeToSign: Math.round(avgTimeToSign * 10) / 10,
          lettersByStatus,
          lettersByMonth,
          recentActivity,
        }
      },

      getSalesKPIData: () => {
        const records = get().salesRecords
        const wonDeals = records.filter((r) => r.stage === "closed_won")
        const lostDeals = records.filter((r) => r.stage === "closed_lost")
        const pipelineDeals = records.filter(
          (r) => r.stage !== "closed_won" && r.stage !== "closed_lost"
        )

        const wonRevenue = wonDeals.reduce(
          (sum, r) => sum + (r.actualValue || r.estimatedValue),
          0
        )
        const lostRevenue = lostDeals.reduce((sum, r) => sum + r.estimatedValue, 0)
        const totalPipeline = pipelineDeals.reduce(
          (sum, r) => sum + r.estimatedValue * (r.probability / 100),
          0
        )

        // Win rate calculation
        const closedDeals = wonDeals.length + lostDeals.length
        const winRate = closedDeals > 0 ? (wonDeals.length / closedDeals) * 100 : 0

        // Average deal size
        const avgDealSize =
          wonDeals.length > 0
            ? wonDeals.reduce(
                (sum, r) => sum + (r.actualValue || r.estimatedValue),
                0
              ) / wonDeals.length
            : 0

        // Average sales cycle (in days)
        const dealsWithCycle = wonDeals.filter((r) => r.closedAt)
        const avgSalesCycle =
          dealsWithCycle.length > 0
            ? dealsWithCycle.reduce((sum, r) => {
                const created = new Date(r.createdAt).getTime()
                const closed = new Date(r.closedAt!).getTime()
                return sum + (closed - created) / (1000 * 60 * 60 * 24)
              }, 0) / dealsWithCycle.length
            : 0

        // Sales by stage
        const stageCounts: Record<SaleStage, { value: number; count: number }> = {
          lead: { value: 0, count: 0 },
          qualified: { value: 0, count: 0 },
          proposal: { value: 0, count: 0 },
          negotiation: { value: 0, count: 0 },
          closed_won: { value: 0, count: 0 },
          closed_lost: { value: 0, count: 0 },
        }
        records.forEach((r) => {
          stageCounts[r.stage].count++
          stageCounts[r.stage].value += r.estimatedValue
        })

        const stageLabels: Record<SaleStage, string> = {
          lead: "Lead",
          qualified: "Qualified",
          proposal: "Proposal",
          negotiation: "Negotiation",
          closed_won: "Won",
          closed_lost: "Lost",
        }

        const salesByStage = [
          {
            stage: stageLabels.lead,
            value: stageCounts.lead.value,
            count: stageCounts.lead.count,
            fill: "var(--chart-3)",
          },
          {
            stage: stageLabels.qualified,
            value: stageCounts.qualified.value,
            count: stageCounts.qualified.count,
            fill: "var(--chart-1)",
          },
          {
            stage: stageLabels.proposal,
            value: stageCounts.proposal.value,
            count: stageCounts.proposal.count,
            fill: "var(--chart-5)",
          },
          {
            stage: stageLabels.negotiation,
            value: stageCounts.negotiation.value,
            count: stageCounts.negotiation.count,
            fill: "var(--primary)",
          },
          {
            stage: stageLabels.closed_won,
            value: stageCounts.closed_won.value,
            count: stageCounts.closed_won.count,
            fill: "var(--chart-2)",
          },
          {
            stage: stageLabels.closed_lost,
            value: stageCounts.closed_lost.value,
            count: stageCounts.closed_lost.count,
            fill: "var(--chart-4)",
          },
        ]

        // Sales by month (static for hydration)
        const salesByMonth = [
          { month: "Oct", won: 72000, lost: 0, pipeline: 45000 },
          { month: "Nov", won: 35000, lost: 18000, pipeline: 60000 },
          { month: "Dec", won: 0, lost: 0, pipeline: 85000 },
          { month: "Jan", won: 80000, lost: 8000, pipeline: 95000 },
          { month: "Feb", won: 0, lost: 0, pipeline: 110000 },
          { month: "Mar", won: 0, lost: 0, pipeline: 165000 },
        ]

        // Sales by source
        const sourceMap: Record<string, { value: number; count: number }> = {}
        records.forEach((r) => {
          if (!sourceMap[r.source]) {
            sourceMap[r.source] = { value: 0, count: 0 }
          }
          sourceMap[r.source].value += r.estimatedValue
          sourceMap[r.source].count++
        })
        const salesBySource = Object.entries(sourceMap)
          .map(([source, data]) => ({
            source,
            value: data.value,
            count: data.count,
          }))
          .sort((a, b) => b.value - a.value)

        // Sales by rep
        const repMap: Record<string, { won: number; pipeline: number; deals: number }> = {}
        records.forEach((r) => {
          if (!repMap[r.assignedTo]) {
            repMap[r.assignedTo] = { won: 0, pipeline: 0, deals: 0 }
          }
          repMap[r.assignedTo].deals++
          if (r.stage === "closed_won") {
            repMap[r.assignedTo].won += r.actualValue || r.estimatedValue
          } else if (r.stage !== "closed_lost") {
            repMap[r.assignedTo].pipeline += r.estimatedValue
          }
        })
        const salesByRep = Object.entries(repMap)
          .map(([rep, data]) => ({
            rep,
            won: data.won,
            pipeline: data.pipeline,
            deals: data.deals,
          }))
          .sort((a, b) => b.won - a.won)

        // Recent deals - use consistent date formatting
        const formatDateConsistent = (date: Date) => {
          const d = new Date(date)
          const year = d.getUTCFullYear()
          const month = String(d.getUTCMonth() + 1).padStart(2, "0")
          const day = String(d.getUTCDate()).padStart(2, "0")
          return `${year}-${month}-${day}`
        }

        const recentDeals = [...records]
          .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
          .slice(0, 5)
          .map((r) => ({
            id: r.id,
            client: r.clientName,
            value: r.estimatedValue,
            stage: r.stage,
            date: formatDateConsistent(r.updatedAt),
          }))

        return {
          totalPipeline: Math.round(totalPipeline),
          wonRevenue,
          lostRevenue,
          avgDealSize: Math.round(avgDealSize),
          winRate: Math.round(winRate * 10) / 10,
          avgSalesCycle: Math.round(avgSalesCycle),
          dealsInPipeline: pipelineDeals.length,
          dealsWon: wonDeals.length,
          dealsLost: lostDeals.length,
          salesByStage,
          salesByMonth,
          salesBySource,
          salesByRep,
          recentDeals,
        }
      },

      // Weekly KPI functions
      addWeeklyKPI: (entryData) => {
        const newEntry: WeeklyKPIEntry = {
          ...entryData,
          id: crypto.randomUUID(),
          createdAt: new Date(),
          updatedAt: new Date(),
        }
        set((state) => ({ weeklyKPIs: [...state.weeklyKPIs, newEntry] }))
      },

      updateWeeklyKPI: (id, updates) => {
        set((state) => ({
          weeklyKPIs: state.weeklyKPIs.map((entry) =>
            entry.id === id
              ? { ...entry, ...updates, updatedAt: new Date() }
              : entry
          ),
        }))
      },

      deleteWeeklyKPI: (id) => {
        set((state) => ({
          weeklyKPIs: state.weeklyKPIs.filter((entry) => entry.id !== id),
        }))
      },

      updateWeeklyGoals: (goals) => {
        set({ weeklyGoals: goals })
      },

      getWeeklyKPIById: (id) => {
        return get().weeklyKPIs.find((entry) => entry.id === id)
      },

      getCurrentWeekKPI: () => {
        const now = new Date()
        const day = now.getDay()
        const mondayOffset = day === 0 ? -6 : 1 - day
        const monday = new Date(now)
        monday.setDate(now.getDate() + mondayOffset)
        monday.setHours(0, 0, 0, 0)
        const mondayStr = monday.toISOString().split("T")[0]
        
        return get().weeklyKPIs.find((entry) => entry.weekStartDate === mondayStr)
      },

      // Meeting functions
      addMeeting: (meetingData) => {
        const newMeeting: Meeting = {
          ...meetingData,
          id: crypto.randomUUID(),
          createdAt: new Date(),
          updatedAt: new Date(),
        }
        set((state) => ({ meetings: [...state.meetings, newMeeting] }))
      },

      updateMeeting: (id, updates) => {
        set((state) => ({
          meetings: state.meetings.map((meeting) =>
            meeting.id === id
              ? { ...meeting, ...updates, updatedAt: new Date() }
              : meeting
          ),
        }))
      },

      deleteMeeting: (id) => {
        set((state) => ({
          meetings: state.meetings.filter((meeting) => meeting.id !== id),
          selectedMeetingId:
            state.selectedMeetingId === id ? null : state.selectedMeetingId,
        }))
      },

      setSelectedMeeting: (id) => set({ selectedMeetingId: id }),

      getMeetingById: (id) => {
        return get().meetings.find((meeting) => meeting.id === id)
      },

      setZoomConnection: (connection) => set({ zoomConnection: connection }),

      clearZoomConnection: () =>
        set({
          zoomConnection: { connected: false },
        }),

      upsertZoomMeetings: (incoming) => {
        set((state) => {
          const byId = new Map(state.meetings.map((m) => [m.id, m]))
          for (const m of incoming) {
            byId.set(m.id, m)
          }
          return { meetings: Array.from(byId.values()) }
        })
      },

      setOutlookConnection: (connection) => set({ outlookConnection: connection }),

      clearOutlookConnection: () =>
        set({ outlookConnection: { connected: false } }),

      upsertOutlookMeetings: (incoming) => {
        set((state) => {
          const byId = new Map(state.meetings.map((m) => [m.id, m]))
          for (const m of incoming) {
            byId.set(m.id, m)
          }
          return { meetings: Array.from(byId.values()) }
        })
      },
    }),
    {
      name: "engagement-store",
      partialize: (state) => ({
        letters: state.letters,
        salesRecords: state.salesRecords,
        weeklyKPIs: state.weeklyKPIs,
        weeklyGoals: state.weeklyGoals,
        meetings: state.meetings,
        zoomConnection: state.zoomConnection,
        outlookConnection: state.outlookConnection,
      }),
      merge: (persisted, current) => {
        const p = persisted as Partial<EngagementStore> | undefined
        return {
          ...current,
          ...p,
          zoomConnection: p?.zoomConnection ?? { connected: false },
          outlookConnection: p?.outlookConnection ?? { connected: false },
        }
      },
    }
  )
)
