import type { Meeting } from "./types"
import {
  extractZoomMeetingNumber,
  findZoomLinksInText,
} from "./zoom-link"

type GraphCalendarEvent = {
  id: string
  subject?: string
  webLink?: string
  start?: { dateTime: string; timeZone?: string }
  end?: { dateTime: string; timeZone?: string }
  body?: { content?: string; contentType?: string }
  location?: { displayName?: string }
  onlineMeeting?: { joinUrl?: string }
  isCancelled?: boolean
}

function parseGraphStart(start?: { dateTime: string; timeZone?: string }): Date {
  if (!start?.dateTime) return new Date()
  const raw = start.dateTime.replace(/(\.\d{3})\d+/, "$1")
  if (start.timeZone === "UTC" || !start.timeZone) {
    const iso = raw.includes("Z") ? raw : `${raw.replace(/\+.*$/, "")}Z`
    return new Date(iso)
  }
  return new Date(raw)
}

function minutesBetween(start: Date, end: Date): number {
  return Math.max(15, Math.round((end.getTime() - start.getTime()) / 60000))
}

export function graphEventToMeeting(evt: GraphCalendarEvent): Meeting | null {
  if (evt.isCancelled) return null

  const start = parseGraphStart(evt.start)
  const end = evt.end ? parseGraphStart(evt.end) : new Date(start.getTime() + 3600000)
  const duration = minutesBetween(start, end)

  const bodyHtml = evt.body?.content ?? ""
  const location = evt.location?.displayName ?? ""
  const zoomFromBody = findZoomLinksInText(bodyHtml)
  const zoomFromLoc = findZoomLinksInText(location)
  const zoomJoinUrl = zoomFromBody[0] ?? zoomFromLoc[0]
  const teamsUrl = evt.onlineMeeting?.joinUrl

  let platform: Meeting["platform"] = "other"
  let meetingUrl: string | undefined
  if (zoomJoinUrl) {
    platform = "zoom"
    meetingUrl = zoomJoinUrl
  } else if (teamsUrl) {
    platform = "teams"
    meetingUrl = teamsUrl
  }

  const now = new Date()
  const zoomMeetingNumber = extractZoomMeetingNumber(zoomJoinUrl)

  return {
    id: `outlook-${evt.id}`,
    title: evt.subject?.trim() || "Calendar event",
    date: start,
    duration,
    participants: [],
    platform,
    meetingUrl,
    zoomJoinUrl,
    transcript: [],
    summary: zoomJoinUrl
      ? "Imported from Outlook Calendar. Join link detected. After the meeting, sync Zoom cloud recordings to pull transcript and recording."
      : teamsUrl
        ? "Imported from Outlook Calendar (Teams meeting)."
        : "Imported from Outlook Calendar. Add a Zoom link to the invite body or location to enable join reminders.",
    keyPoints: [],
    actionItems: [],
    tags: ["outlook-calendar"],
    outlookEventId: evt.id,
    outlookWebLink: evt.webLink,
    zoomMeetingNumber,
    createdAt: now,
    updatedAt: now,
  }
}
