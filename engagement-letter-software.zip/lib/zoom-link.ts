/** Zoom join / personal room URLs inside calendar text or HTML */
const ZOOM_URL =
  /https?:\/\/(?:[\w-]+\.)?zoom\.us\/(?:j\/[\d?&=\w.-]+|my\/[\w?&=\w.-]+)/gi

export function findZoomLinksInText(htmlOrText: string): string[] {
  if (!htmlOrText) return []
  const plain = htmlOrText.replace(/<[^>]+>/g, " ")
  const found = new Set<string>()
  let m: RegExpExecArray | null
  const re = new RegExp(ZOOM_URL.source, "gi")
  while ((m = re.exec(plain)) !== null) {
    let url = m[0].replace(/[.,;)\]]+$/g, "")
    if (url.length > 12) found.add(url)
  }
  return [...found]
}

export function extractZoomMeetingNumber(url: string | undefined): string | undefined {
  if (!url) return undefined
  const m = url.match(/\/j\/(\d+)/i)
  return m?.[1]
}
