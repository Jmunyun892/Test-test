import type { Meeting, MeetingTranscriptSegment } from "./types"
import type { ZoomRecordingMeeting } from "./zoom"

function formatVttTimestamp(start: string): string {
  const t = start.trim().split(/\s/)[0] ?? start
  const parts = t.split(":")
  if (parts.length >= 3) {
    const h = parseInt(parts[0]!, 10) || 0
    const m = parseInt(parts[1]!, 10) || 0
    const sec = parseFloat(parts[2]!) || 0
    const s = Math.floor(sec)
    if (h > 0) {
      return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    }
    return `${m}:${String(s).padStart(2, "0")}`
  }
  return t
}

/** Parse Zoom / WebVTT transcript content into speaker segments. */
export function parseWebVTT(vtt: string): MeetingTranscriptSegment[] {
  const segments: MeetingTranscriptSegment[] = []
  const normalized = vtt.replace(/\r\n/g, "\n")
  const lines = normalized.split("\n")
  let i = 0

  if (lines[0]?.startsWith("WEBVTT")) {
    while (i < lines.length && lines[i]!.trim() !== "") i++
    i++
  }

  while (i < lines.length) {
    while (i < lines.length && lines[i]!.trim() === "") i++
    if (i >= lines.length) break

    let timeLine = lines[i]!
    if (!timeLine.includes("-->")) {
      i++
      timeLine = lines[i] ?? ""
    }
    if (!timeLine.includes("-->")) break

    const startRaw = timeLine.split("-->")[0]?.trim() ?? ""
    const timestamp = formatVttTimestamp(startRaw)
    i++

    const textLines: string[] = []
    while (i < lines.length && lines[i]!.trim() !== "") {
      textLines.push(lines[i]!)
      i++
    }

    let text = textLines.join(" ").trim()
    if (!text) continue

    let speaker = "Speaker"
    const vClosed = text.match(/^<v\s+([^>]+)>([\s\S]*)<\/v>$/i)
    if (vClosed) {
      speaker = vClosed[1]!.trim()
      text = vClosed[2]!.trim()
    } else {
      const vOpen = text.match(/^<v\s+([^>]+)>([\s\S]*)$/i)
      if (vOpen) {
        speaker = vOpen[1]!.trim()
        text = vOpen[2]!.replace(/<\/v>\s*$/i, "").trim()
      }
    }

    text = text.replace(/<[^>]+>/g, "").trim()
    if (text) {
      segments.push({ timestamp, speaker, text })
    }
  }

  return segments
}

export function deriveNotesFromTranscript(
  segments: MeetingTranscriptSegment[]
): { summary: string; keyPoints: string[]; actionItems: string[] } {
  const fullText = segments.map((s) => s.text).join(" ")

  if (!fullText.trim()) {
    return {
      summary:
        "This recording has no parsed transcript text. Enable audio transcription in Zoom cloud settings to get automatic notes.",
      keyPoints: [],
      actionItems: [],
    }
  }

  const summary =
    fullText.length > 600
      ? `${fullText.slice(0, 597).trim()}…`
      : fullText.trim()

  const sentences = fullText
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 24)

  const keyPoints = sentences.slice(0, 6)

  const actionItems: string[] = []
  const actionHints =
    /\b(will|we'll|let me|i'll|send|follow up|schedule|action|todo|next step)\b/i
  for (const seg of segments) {
    if (actionHints.test(seg.text) && seg.text.length > 15 && seg.text.length < 220) {
      actionItems.push(seg.text)
    }
    if (actionItems.length >= 5) break
  }

  return { summary, keyPoints, actionItems }
}

export function zoomRecordingToMeetingId(uuid: string): string {
  const safe = encodeURIComponent(uuid)
  return `zoom-${safe}`
}

/** Build a Meeting from one Zoom cloud recording instance. */
export function meetingFromZoomRecording(input: {
  recording: ZoomRecordingMeeting
  transcript: MeetingTranscriptSegment[]
  hostEmail?: string
}): Meeting {
  const { recording, transcript, hostEmail } = input
  const { summary, keyPoints, actionItems } = deriveNotesFromTranscript(transcript)

  const videoFile = recording.recording_files?.find(
    (f) => f.file_type === "MP4" && f.play_url
  )
  const audioFile = recording.recording_files?.find(
    (f) => f.file_type === "M4A" && f.play_url
  )
  const playUrl = videoFile?.play_url ?? audioFile?.play_url

  const now = new Date()
  const participants = hostEmail ? [hostEmail] : []

  return {
    id: zoomRecordingToMeetingId(recording.uuid),
    title: recording.topic || "Zoom meeting",
    date: new Date(recording.start_time),
    duration: Math.max(1, recording.duration || 1),
    participants,
    platform: "zoom",
    meetingUrl: recording.share_url,
    recordingUrl: playUrl,
    transcript,
    summary,
    keyPoints,
    actionItems,
    tags: ["zoom", "cloud-recording"],
    zoomRecordingUuid: recording.uuid,
    createdAt: now,
    updatedAt: now,
  }
}
