export type LetterStatus = "draft" | "sent" | "viewed" | "won" | "expired" | "rejected"

export interface EngagementLetter {
  id: string
  title: string
  clientName: string
  clientEmail: string
  serviceType: string
  content: string
  status: LetterStatus
  createdAt: Date
  updatedAt: Date
  sentAt?: Date
  signedAt?: Date
  expiresAt?: Date
  value: number
}

export interface KPIData {
  totalLetters: number
  signedLetters: number
  pendingLetters: number
  totalValue: number
  signedValue: number
  conversionRate: number
  averageTimeToSign: number
  lettersByStatus: { status: string; count: number; fill: string }[]
  lettersByMonth: { month: string; sent: number; signed: number }[]
  recentActivity: { date: string; action: string; letter: string }[]
}

export type SaleStage = "lead" | "qualified" | "proposal" | "negotiation" | "closed_won" | "closed_lost"

export interface SalesRecord {
  id: string
  clientName: string
  contactEmail: string
  serviceType: string
  estimatedValue: number
  actualValue?: number
  stage: SaleStage
  probability: number
  source: string
  assignedTo: string
  createdAt: Date
  updatedAt: Date
  expectedCloseDate: Date
  closedAt?: Date
  notes: string
  linkedLetterId?: string
}

export interface SalesKPIData {
  totalPipeline: number
  wonRevenue: number
  lostRevenue: number
  avgDealSize: number
  winRate: number
  avgSalesCycle: number
  dealsInPipeline: number
  dealsWon: number
  dealsLost: number
  salesByStage: { stage: string; value: number; count: number; fill: string }[]
  salesByMonth: { month: string; won: number; lost: number; pipeline: number }[]
  salesBySource: { source: string; value: number; count: number }[]
  salesByRep: { rep: string; won: number; pipeline: number; deals: number }[]
  recentDeals: { id: string; client: string; value: number; stage: SaleStage; date: string }[]
}

// Weekly KPI Tracker Types
export interface WeeklyKPIEntry {
  id: string
  weekStartDate: string // ISO date string (Monday of the week)
  weekEndDate: string // ISO date string (Sunday of the week)
  discoveryCalls: number
  unqualifiedDeals: number
  pricingCalls: number
  mrrProposed: number
  backworkProposed: number
  backworkClosed: number
  mrrClosed: number
  numberOfClients: number
  networkingEvents: number
  clientCheckInCalls: number
  notes?: string
  createdAt: Date
  updatedAt: Date
}

export interface WeeklyKPIGoals {
  discoveryCalls: number
  unqualifiedDeals: number
  pricingCalls: number
  mrrProposed: number
  backworkProposed: number
  backworkClosed: number
  mrrClosed: number
  numberOfClients: number
  networkingEvents: number
  clientCheckInCalls: number
}

// Meeting/Notetaker Types
export interface MeetingTranscriptSegment {
  timestamp: string
  speaker: string
  text: string
}

export interface Meeting {
  id: string
  title: string
  date: Date
  duration: number // in minutes
  participants: string[]
  platform: "zoom" | "teams" | "google_meet" | "other"
  meetingUrl?: string
  /** Zoom join URL parsed from Outlook/calendar text */
  zoomJoinUrl?: string
  /** Microsoft Graph event id (without outlook- prefix) */
  outlookEventId?: string
  outlookWebLink?: string
  zoomMeetingNumber?: string
  recordingUrl?: string
  thumbnailUrl?: string
  transcript: MeetingTranscriptSegment[]
  summary: string
  keyPoints: string[]
  actionItems: string[]
  clientName?: string
  tags: string[]
  /** Stable Zoom cloud recording instance id for upserts when syncing */
  zoomRecordingUuid?: string
  createdAt: Date
  updatedAt: Date
}

// Zoom Integration Types
export interface ZoomConnection {
  connected: boolean
  accessToken?: string
  refreshToken?: string
  expiresAt?: number
  userId?: string
  email?: string
  accountId?: string
  displayName?: string
  connectedAt?: string // ISO string in persisted store
}

/** Microsoft 365 / Outlook calendar via Graph */
export interface OutlookConnection {
  connected: boolean
  accessToken?: string
  refreshToken?: string
  expiresAt?: number
  userId?: string
  email?: string
  displayName?: string
  connectedAt?: string
}

export interface ZoomMeeting {
  id: string
  uuid: string
  topic: string
  start_time: string
  duration: number
  recording_files?: ZoomRecording[]
}

export interface ZoomRecording {
  id: string
  meeting_id: string
  recording_start: string
  recording_end: string
  file_type: string
  file_size: number
  play_url?: string
  download_url?: string
  status: string
}
