import type { Meeting } from "./types"

export type SerializedZoomMeeting = Omit<
  Meeting,
  "date" | "createdAt" | "updatedAt"
> & {
  date: string
  createdAt: string
  updatedAt: string
}

export function hydrateZoomMeeting(raw: SerializedZoomMeeting): Meeting {
  return {
    ...raw,
    date: new Date(raw.date),
    createdAt: new Date(raw.createdAt),
    updatedAt: new Date(raw.updatedAt),
  }
}

export function isZoomOAuthConfigured(): boolean {
  return Boolean(
    typeof process.env.NEXT_PUBLIC_ZOOM_CLIENT_ID === "string" &&
      process.env.NEXT_PUBLIC_ZOOM_CLIENT_ID.length > 0
  )
}
