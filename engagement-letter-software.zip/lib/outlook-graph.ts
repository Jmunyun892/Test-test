export const OUTLOOK_OAUTH = {
  clientId: process.env.NEXT_PUBLIC_MICROSOFT_CLIENT_ID || "",
  clientSecret: process.env.MICROSOFT_CLIENT_SECRET || "",
  redirectUri:
    process.env.NEXT_PUBLIC_MICROSOFT_REDIRECT_URI ||
    "http://localhost:3000/api/outlook/callback",
  tenant: process.env.MICROSOFT_TENANT_ID || "common",
  scopes: [
    "offline_access",
    "Calendars.Read",
    "User.Read",
  ].join(" "),
}

export function getOutlookAuthorizeUrl(state: string): string {
  const tenant = OUTLOOK_OAUTH.tenant
  const params = new URLSearchParams({
    client_id: OUTLOOK_OAUTH.clientId,
    response_type: "code",
    redirect_uri: OUTLOOK_OAUTH.redirectUri,
    response_mode: "query",
    scope: OUTLOOK_OAUTH.scopes,
    state,
  })
  return `https://login.microsoftonline.com/${tenant}/oauth2/v2.0/authorize?${params}`
}

export async function exchangeOutlookCode(code: string): Promise<{
  access_token: string
  refresh_token?: string
  expires_in: number
  scope: string
}> {
  const tenant = OUTLOOK_OAUTH.tenant
  const body = new URLSearchParams({
    client_id: OUTLOOK_OAUTH.clientId,
    client_secret: OUTLOOK_OAUTH.clientSecret,
    code,
    redirect_uri: OUTLOOK_OAUTH.redirectUri,
    grant_type: "authorization_code",
    scope: OUTLOOK_OAUTH.scopes,
  })

  const res = await fetch(
    `https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    }
  )

  if (!res.ok) {
    const t = await res.text()
    throw new Error(`Outlook token exchange failed: ${t}`)
  }
  return res.json()
}

export async function refreshOutlookToken(refreshToken: string): Promise<{
  access_token: string
  refresh_token?: string
  expires_in: number
}> {
  const tenant = OUTLOOK_OAUTH.tenant
  const body = new URLSearchParams({
    client_id: OUTLOOK_OAUTH.clientId,
    client_secret: OUTLOOK_OAUTH.clientSecret,
    refresh_token: refreshToken,
    grant_type: "refresh_token",
    scope: OUTLOOK_OAUTH.scopes,
  })

  const res = await fetch(
    `https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    }
  )

  if (!res.ok) {
    const t = await res.text()
    throw new Error(`Outlook token refresh failed: ${t}`)
  }
  return res.json()
}

export class GraphApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.name = "GraphApiError"
    this.status = status
  }
}

export async function graphGetMe(accessToken: string): Promise<{
  id: string
  displayName?: string
  userPrincipalName?: string
  mail?: string
}> {
  const res = await fetch("https://graph.microsoft.com/v1.0/me", {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  })
  if (!res.ok) {
    throw new GraphApiError(await res.text(), res.status)
  }
  return res.json()
}

type GraphCalendarEvent = {
  id: string
  subject?: string
  webLink?: string
  start?: { dateTime: string; timeZone?: string }
  end?: { dateTime: string; timeZone?: string }
  body?: { content?: string; contentType?: string }
  location?: { displayName?: string }
  onlineMeeting?: { joinUrl?: string }
  isCancelled?: boolean
}

export async function graphListCalendarView(
  accessToken: string,
  start: Date,
  end: Date
): Promise<GraphCalendarEvent[]> {
  const startIso = start.toISOString()
  const endIso = end.toISOString()
  const q = new URLSearchParams({
    startDateTime: startIso,
    endDateTime: endIso,
    $orderby: "start/dateTime",
    $top: "200",
  })

  const url = `https://graph.microsoft.com/v1.0/me/calendarView?${q}`
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Prefer: 'outlook.timezone="UTC"',
    },
  })

  if (!res.ok) {
    throw new GraphApiError(await res.text(), res.status)
  }

  const data = (await res.json()) as { value?: GraphCalendarEvent[] }
  return data.value ?? []
}
