import type { Meeting } from "./types"

export type SerializedOutlookMeeting = Omit<
  Meeting,
  "date" | "createdAt" | "updatedAt"
> & {
  date: string
  createdAt: string
  updatedAt: string
}

export function hydrateOutlookMeeting(raw: SerializedOutlookMeeting): Meeting {
  return {
    ...raw,
    date: new Date(raw.date),
    createdAt: new Date(raw.createdAt),
    updatedAt: new Date(raw.updatedAt),
  }
}

export function isOutlookOAuthConfigured(): boolean {
  return Boolean(
    typeof process.env.NEXT_PUBLIC_MICROSOFT_CLIENT_ID === "string" &&
      process.env.NEXT_PUBLIC_MICROSOFT_CLIENT_ID.length > 0
  )
}
