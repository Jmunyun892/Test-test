/** Zoom cloud `play_url` / `download_url` usually requires `access_token` as a query param for playback. */
export function zoomRecordingPlaybackUrl(
  recordingUrl: string | undefined,
  accessToken: string | undefined
): string | undefined {
  if (!recordingUrl) return undefined
  const host = (() => {
    try {
      return new URL(recordingUrl).hostname
    } catch {
      return ""
    }
  })()
  const isZoom =
    host.includes("zoom.us") ||
    host.includes("zoomgov.com") ||
    host.includes("zoom.com")
  if (!isZoom || !accessToken?.trim()) return recordingUrl
  const sep = recordingUrl.includes("?") ? "&" : "?"
  return `${recordingUrl}${sep}access_token=${encodeURIComponent(accessToken)}`
}
